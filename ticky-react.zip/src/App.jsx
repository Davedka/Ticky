import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Termek from './pages/Termek'
import Tanar from './pages/Tanar'
import Osztaly from './pages/Osztaly'
import Terem from './pages/Terem'
import Napirend from './pages/Napirend'
import QR from './pages/QR'
import Login from './pages/Login'
import Admin from './pages/Admin'
import Support from './pages/Support'

function NotFound() {
  return (
    <div style={{ background: '#060f1e', color: 'rgba(255,255,255,.5)', fontFamily: 'sans-serif', display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', flexDirection: 'column', gap: 12 }}>
      <h1 style={{ color: 'white', fontSize: 48 }}>404</h1>
      <p>Az oldal nem található</p>
      <a href="/" style={{ color: '#f0c76b', textDecoration: 'none' }}>← Vissza</a>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/termek" element={<Termek />} />
        <Route path="/tanar" element={<Tanar />} />
        <Route path="/tanar/:kod" element={<Tanar />} />
        <Route path="/osztaly" element={<Osztaly />} />
        <Route path="/osztaly/:kod" element={<Osztaly />} />
        <Route path="/terem/:szam" element={<Terem />} />
        <Route path="/terem/:szam/nap" element={<Napirend />} />
        <Route path="/qr" element={<QR />} />
        <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/support" element={<Support />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  )
}
