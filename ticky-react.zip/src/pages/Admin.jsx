import { useState, useEffect, useCallback } from 'react'

function esc(v) { return String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;') }

function adminFetch(url, opts = {}) {
  return fetch(url, { ...opts, headers: { 'Content-Type': 'application/json', 'X-Ticky-Admin': '1', ...(opts.headers || {}) } })
}

function useToastSimple() {
  const [toasts, setToasts] = useState([])
  const add = (msg, type = 'ok') => {
    const id = Date.now()
    setToasts(t => [...t, { id, msg, type }])
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3200)
  }
  const Toasts = () => toasts.map(t => (
    <div key={t.id} className={`toast ${t.type}`}>{t.msg}</div>
  ))
  return { toast: add, Toasts }
}

// ── Section components ────────────────────────────────────────────────

function Dashboard({ toast }) {
  const [stats, setStats] = useState(null)
  const [mai, setMai] = useState(null)

  const load = useCallback(async () => {
    try {
      const [td, tnd, ta] = await Promise.all([
        fetch('/api/termek').then(r => r.json()),
        fetch('/api/tanarok').then(r => r.json()),
        fetch('/api/termek?allapot=1').then(r => r.json()),
      ])
      const fo = (ta.termek || []).filter(t => t.allapot === 'foglalt').length
      const sz = (ta.termek || []).filter(t => t.allapot === 'szabad').length
      setStats({ termek: td.count || 0, tanarok: tnd.count || 0, foglalt: fo, szabad: sz, nap: ta.nap, szunet: ta.szunet })
      setMai((ta.termek || []).filter(t => t.allapot === 'foglalt'))
    } catch(e) { toast('Betöltési hiba', 'err') }
  }, [toast])

  useEffect(() => { load() }, [load])

  const napNev = ['Vasárnap','Hétfő','Kedd','Szerda','Csütörtök','Péntek','Szombat'][new Date().getDay()]

  return (
    <div>
      <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 26, fontWeight: 700, marginBottom: 4 }}>Dashboard</h1>
      <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)', marginBottom: 20 }}>Rendszer állapot áttekintés</p>

      {stats?.szunet && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 18px', borderRadius: 12, background: 'linear-gradient(135deg,rgba(200,151,42,.15),rgba(26,74,138,.15))', border: '1px solid rgba(200,151,42,.3)', marginBottom: 20 }}>
          <span style={{ fontSize: 24 }}>🌙</span>
          <div>
            <p style={{ fontWeight: 700, color: '#f0c76b', fontSize: 15 }}>{stats.szunet} – most szünet van</p>
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,.5)', marginTop: 2 }}>Az órarendek nem aktívak</p>
          </div>
        </div>
      )}

      {!stats ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 12, marginBottom: 20 }}>
          {Array(4).fill(0).map((_, i) => <div key={i} className="skel" style={{ height: 80, borderRadius: 12 }} />)}
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 12, marginBottom: 20 }}>
          {[
            { label: 'Termek', val: stats.termek, sub: 'regisztrált', cls: 'gold' },
            { label: 'Tanárok', val: stats.tanarok, sub: 'tanár kód', cls: '' },
            { label: 'Foglalt most', val: stats.nap === 0 ? '–' : stats.foglalt, sub: stats.nap === 0 ? 'hétvége' : 'aktív óra', cls: 'red' },
            { label: 'Szabad most', val: stats.nap === 0 ? '–' : stats.szabad, sub: stats.nap === 0 ? 'hétvége' : 'elérhető', cls: 'green' },
          ].map(s => (
            <div key={s.label} style={{ borderRadius: 12, padding: '16px 18px', border: '1px solid rgba(255,255,255,.08)', background: s.cls === 'gold' ? 'rgba(200,151,42,.07)' : s.cls === 'red' ? 'rgba(232,51,74,.07)' : s.cls === 'green' ? 'rgba(0,200,150,.07)' : 'rgba(255,255,255,.03)', borderColor: s.cls === 'gold' ? 'rgba(200,151,42,.2)' : s.cls === 'red' ? 'rgba(232,51,74,.2)' : s.cls === 'green' ? 'rgba(0,200,150,.2)' : undefined }}>
              <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: '.07em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', marginBottom: 6 }}>{s.label}</div>
              <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 32, fontWeight: 700, color: s.cls === 'gold' ? '#f0c76b' : s.cls === 'red' ? '#ff6b82' : s.cls === 'green' ? '#00c896' : 'white', lineHeight: 1 }}>{s.val}</div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', marginTop: 4 }}>{s.sub}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)', borderRadius: 14, padding: '20px 24px', marginBottom: 20 }}>
        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          🔌 Rendszer státusz
          <button onClick={load} className="btn btn-ghost btn-sm">🔄 Frissít</button>
        </div>
        {[
          { label: 'API Backend', status: stats ? 'Online' : '…', ok: !!stats },
          { label: 'Supabase DB', status: stats?.termek > 0 ? 'Kapcsolódva' : 'Ellenőrizd', ok: stats?.termek > 0 },
          { label: 'Időzóna', status: 'Europe/Budapest', tag: true },
          { label: 'Mai nap', status: napNev, tag: true },
        ].map(r => (
          <div key={r.label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid rgba(255,255,255,.06)' }}>
            <span style={{ fontSize: 14, fontWeight: 500, color: 'rgba(255,255,255,.7)' }}>{r.label}</span>
            <span className={`tag ${r.tag ? 'tag-gold' : r.ok ? 'tag-green' : 'tag-gold'}`}>{r.status}</span>
          </div>
        ))}
      </div>

      <div style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)', borderRadius: 14, padding: '20px 24px' }}>
        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, marginBottom: 16 }}>📅 Mai foglalt termek</div>
        {mai === null ? <div className="skel" style={{ height: 100, borderRadius: 10 }} />
          : stats?.szunet ? <div style={{ textAlign: 'center', padding: 20, color: 'rgba(255,255,255,.4)' }}>🌙 Szünet – az órarendek nem aktívak</div>
          : stats?.nap === 0 ? <div style={{ textAlign: 'center', padding: 20, color: 'rgba(255,255,255,.35)' }}>🌙 Hétvége</div>
          : !mai.length ? <div style={{ textAlign: 'center', padding: 20, color: 'rgba(255,255,255,.35)' }}>✅ Jelenleg nincs foglalt terem</div>
          : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead><tr>{['Terem','Tanár','Osztály','Tantárgy','Időpont'].map(h => <th key={h} style={{ fontSize: 11, fontWeight: 600, letterSpacing: '.07em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid rgba(255,255,255,.08)', whiteSpace: 'nowrap' }}>{h}</th>)}</tr></thead>
              <tbody>{mai.map((t, i) => (
                <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,.05)' }}>
                  <td style={{ padding: '10px 14px' }}><a href={`/terem/${t.terem_szam}`} style={{ color: '#f0c76b', fontFamily: "'Playfair Display',serif", fontSize: 15, fontWeight: 700 }}>{t.terem_szam}</a></td>
                  <td style={{ padding: '10px 14px', fontSize: 13, color: 'rgba(255,255,255,.75)' }}>{t.aktualis?.tanar || '–'}</td>
                  <td style={{ padding: '10px 14px', fontSize: 13, color: 'rgba(255,255,255,.75)' }}>{t.aktualis?.osztaly || '–'}</td>
                  <td style={{ padding: '10px 14px', fontSize: 13, color: 'rgba(255,255,255,.75)' }}>{t.aktualis?.tantargy || '–'}</td>
                  <td style={{ padding: '10px 14px', fontSize: 12, color: 'rgba(255,255,255,.4)', fontFamily: "'DM Mono',monospace" }}>{t.aktualis?.kezdes}–{t.aktualis?.vegzes}</td>
                </tr>
              ))}</tbody>
            </table>
          )}
      </div>
    </div>
  )
}

function Tanarok({ toast }) {
  const [all, setAll] = useState([])
  const [search, setSearch] = useState('')
  const [editKod, setEditKod] = useState('')
  const [editNev, setEditNev] = useState('')
  const [msg, setMsg] = useState('')

  const load = useCallback(async () => {
    try { const d = await fetch('/api/tanarok').then(r => r.json()); setAll(d.tanarok || []) } catch(e) {}
  }, [])
  useEffect(() => { load() }, [load])

  const filtered = search ? all.filter(t => (t.rovid_nev + ' ' + (t.nev || '')).toLowerCase().includes(search.toLowerCase())) : all

  const editTanar = (kod, nev) => {
    setEditKod(kod); setEditNev(nev || '')
    document.getElementById('admin-edit-nev')?.focus()
  }

  const save = async () => {
    if (!editKod) { toast('Kattints egy ✏️ gombra!', 'err'); return }
    try {
      const res = await adminFetch('/api/admin/tanar', { method: 'POST', body: JSON.stringify({ kod: editKod, nev: editNev }) })
      const d = await res.json()
      if (d.ok) { toast(`✅ ${editKod} elmentve`); setMsg(`✓ Elmentve: ${editNev || '(törölve)'}`); setEditKod(''); setEditNev(''); load() }
      else toast(d.error || 'Hiba', 'err')
    } catch(e) { toast('API hiba', 'err') }
  }

  return (
    <div>
      <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 26, fontWeight: 700, marginBottom: 4 }}>Tanárok</h1>
      <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)', marginBottom: 20 }}>Teljes nevek hozzáadása a tanár kódokhoz</p>

      <div style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)', borderRadius: 14, padding: '20px 24px', marginBottom: 20 }}>
        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, marginBottom: 16 }}>✏️ Név szerkesztése</div>
        <div style={{ display: 'grid', gridTemplateColumns: '130px 1fr 90px', gap: 8, alignItems: 'center' }}>
          <input className="inp inp-sm" value={editKod} placeholder="Kód" readOnly style={{ fontFamily: "'DM Mono',monospace", textTransform: 'uppercase' }} />
          <input id="admin-edit-nev" className="inp inp-sm" value={editNev} onChange={e => setEditNev(e.target.value)} placeholder="Teljes név (pl. Kovács János)" onKeyDown={e => e.key === 'Enter' && save()} />
          <button className="btn btn-gold btn-sm" onClick={save} style={{ whiteSpace: 'nowrap', width: '100%', justifyContent: 'center' }}>Mentés</button>
        </div>
        {msg && <p style={{ fontSize: 12, color: '#00c896', marginTop: 8 }}>{msg}</p>}
      </div>

      <div style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)', borderRadius: 14, padding: '20px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700 }}>👩‍🏫 Tanárlista</div>
          <span style={{ fontSize: 12, color: 'rgba(255,255,255,.35)', fontFamily: "'DM Mono',monospace" }}>{all.length} tanár</span>
        </div>
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,.3)', fontSize: 13 }}>🔍</span>
          <input type="search" className="inp inp-sm" style={{ paddingLeft: 36 }} placeholder="Keresés…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr>{['Kód','Teljes név',''].map(h => <th key={h} style={{ fontSize: 11, fontWeight: 600, letterSpacing: '.07em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid rgba(255,255,255,.08)' }}>{h}</th>)}</tr></thead>
          <tbody>{filtered.map(t => (
            <tr key={t.rovid_nev} style={{ borderBottom: '1px solid rgba(255,255,255,.05)' }}>
              <td style={{ padding: '10px 14px' }}><span className="tag tag-blue">{t.rovid_nev}</span></td>
              <td style={{ padding: '10px 14px', fontSize: 13, color: t.nev ? 'rgba(255,255,255,.85)' : 'rgba(255,255,255,.25)' }}>{t.nev || '– nincs megadva –'}</td>
              <td style={{ padding: '10px 14px' }}><button className="btn btn-ghost btn-sm" onClick={() => editTanar(t.rovid_nev, t.nev || '')}>✏️</button></td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  )
}

function Szunetek({ toast }) {
  const [all, setAll] = useState([])
  const [loading, setLoading] = useState(true)
  const [nev, setNev] = useState(''); const [kezdet, setKezdet] = useState(''); const [vege, setVege] = useState('')
  const [msg, setMsg] = useState('')
  const [modal, setModal] = useState(null)

  const load = useCallback(async () => {
    try { const d = await adminFetch('/api/admin/szunetek').then(r => r.json()); setAll(d.szunetek || []); setLoading(false) }
    catch(e) { setLoading(false) }
  }, [])
  useEffect(() => { load() }, [load])

  const create = async () => {
    if (!nev || !kezdet || !vege) { setMsg('❌ Minden mező kötelező'); return }
    try {
      const res = await adminFetch('/api/admin/szunet', { method: 'POST', body: JSON.stringify({ nev, kezdet, vege }) })
      const d = await res.json()
      if (d.ok) { toast('✅ Szünet hozzáadva'); setNev(''); setKezdet(''); setVege(''); setMsg(''); load() }
      else setMsg('❌ ' + (d.error || 'Hiba'))
    } catch(e) { toast('API hiba', 'err') }
  }

  const del = async (id, n) => {
    if (!confirm(n + ' törlése?')) return
    try {
      const res = await adminFetch('/api/admin/szunet/' + id, { method: 'DELETE' })
      const d = await res.json()
      if (d.ok) { toast('🗑️ Törölve'); load() } else toast(d.error || 'Hiba', 'err')
    } catch(e) { toast('API hiba', 'err') }
  }

  const save = async () => {
    if (!modal) return
    try {
      const res = await adminFetch('/api/admin/szunet/' + modal.id, { method: 'PATCH', body: JSON.stringify({ nev: modal.nev, kezdet: modal.kezdet, vege: modal.vege }) })
      const d = await res.json()
      if (d.ok) { toast('✅ Frissítve'); setModal(null); load() } else toast(d.error || 'Hiba', 'err')
    } catch(e) { toast('API hiba', 'err') }
  }

  const ma = new Date().toISOString().slice(0, 10)
  const aktiv = all.find(s => ma >= s.kezdet && ma <= s.vege)

  return (
    <div>
      <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 26, fontWeight: 700, marginBottom: 4 }}>Szünetek</h1>
      <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)', marginBottom: 20 }}>Szünet idején a tanár- és osztálynézet „Szünet van" üzenetet mutat</p>

      {aktiv && (
        <div style={{ display: 'flex', gap: 12, padding: '14px 20px', borderRadius: 12, background: 'rgba(200,151,42,.12)', border: '1px solid rgba(200,151,42,.3)', marginBottom: 16 }}>
          <span style={{ fontSize: 24 }}>🌙</span>
          <div><p style={{ fontWeight: 700, color: '#f0c76b', fontSize: 15 }}>MOST SZÜNET VAN: {aktiv.nev}</p><p style={{ fontSize: 12, color: 'rgba(255,255,255,.5)', marginTop: 2 }}>{aktiv.kezdet} – {aktiv.vege}</p></div>
        </div>
      )}

      <div style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)', borderRadius: 14, padding: '20px 24px', marginBottom: 20 }}>
        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, marginBottom: 16 }}>➕ Új szünet hozzáadása</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 140px 140px auto', gap: 8, alignItems: 'flex-end' }}>
          {[['Szünet neve *', nev, setNev, 'pl. Tavaszi szünet', 'text'], ['Kezdet *', kezdet, setKezdet, '', 'date'], ['Vége *', vege, setVege, '', 'date']].map(([l, v, set, p, t]) => (
            <div key={l}>
              <label style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.06em', display: 'block', marginBottom: 5 }}>{l}</label>
              <input type={t} className="inp inp-sm" value={v} onChange={e => set(e.target.value)} placeholder={p} style={{ colorScheme: 'dark' }} />
            </div>
          ))}
          <button className="btn btn-gold btn-sm" onClick={create}>Hozzáadás</button>
        </div>
        {msg && <p style={{ fontSize: 12, color: '#ff6b82', marginTop: 8 }}>{msg}</p>}
      </div>

      <div style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)', borderRadius: 14, padding: '20px 24px' }}>
        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, marginBottom: 16 }}>📅 Beállított szünetek <span style={{ fontSize: 12, color: 'rgba(255,255,255,.35)', fontFamily: "'DM Mono',monospace", fontWeight: 400 }}>{all.length} szünet</span></div>
        {loading ? <div className="skel" style={{ height: 100, borderRadius: 10 }} /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{['Szünet neve','Kezdet','Vége','Státusz',''].map(h => <th key={h} style={{ fontSize: 11, fontWeight: 600, letterSpacing: '.07em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid rgba(255,255,255,.08)' }}>{h}</th>)}</tr></thead>
            <tbody>{all.map(s => {
              let status, cls
              if (ma < s.kezdet) { status = 'Közelgő'; cls = 'tag-blue' }
              else if (ma <= s.vege) { status = '● Aktív most'; cls = 'tag-gold' }
              else { status = 'Lejárt'; cls = 'tag-gray' }
              return (
                <tr key={s.id} style={{ borderBottom: '1px solid rgba(255,255,255,.05)' }}>
                  <td style={{ padding: '10px 14px', fontWeight: 600 }}>{s.nev}</td>
                  <td style={{ padding: '10px 14px', fontSize: 12, fontFamily: "'DM Mono',monospace", color: 'rgba(255,255,255,.6)' }}>{s.kezdet}</td>
                  <td style={{ padding: '10px 14px', fontSize: 12, fontFamily: "'DM Mono',monospace", color: 'rgba(255,255,255,.6)' }}>{s.vege}</td>
                  <td style={{ padding: '10px 14px' }}><span className={`tag ${cls}`}>{status}</span></td>
                  <td style={{ padding: '10px 14px', display: 'flex', gap: 5 }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => setModal({ ...s })}>✏️</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => del(s.id, s.nev)} style={{ color: '#ff6b82' }}>🗑️</button>
                  </td>
                </tr>
              )
            })}</tbody>
          </table>
        )}
      </div>

      {modal && (
        <div onClick={e => e.target === e.currentTarget && setModal(null)} style={{ display: 'flex', position: 'fixed', inset: 0, zIndex: 400, background: 'rgba(4,9,15,.85)', backdropFilter: 'blur(8px)', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ background: '#0d1f3a', border: '1px solid rgba(255,255,255,.12)', borderRadius: 16, padding: 24, width: '100%', maxWidth: 440, margin: 16 }}>
            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, marginBottom: 16 }}>Szünet szerkesztése</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 16 }}>
              <div><label style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.06em', display: 'block', marginBottom: 5 }}>Szünet neve</label><input className="inp" value={modal.nev} onChange={e => setModal(m => ({ ...m, nev: e.target.value }))} /></div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <div><label style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.06em', display: 'block', marginBottom: 5 }}>Kezdet</label><input type="date" className="inp" value={modal.kezdet} onChange={e => setModal(m => ({ ...m, kezdet: e.target.value }))} style={{ colorScheme: 'dark' }} /></div>
                <div><label style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.06em', display: 'block', marginBottom: 5 }}>Vége</label><input type="date" className="inp" value={modal.vege} onChange={e => setModal(m => ({ ...m, vege: e.target.value }))} style={{ colorScheme: 'dark' }} /></div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-gold" style={{ flex: 1 }} onClick={save}>Mentés</button>
              <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setModal(null)}>Mégse</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function Felhasznalok({ toast }) {
  const [all, setAll] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [form, setForm] = useState({ fnev: '', nev: '', pw: '', szerep: 'admin' })
  const [msg, setMsg] = useState('')
  const [pwModal, setPwModal] = useState(null)
  const [newPw, setNewPw] = useState('')

  const load = useCallback(async () => {
    try { const d = await adminFetch('/api/admin/felhasznalok').then(r => r.json()); setAll(d.felhasznalok || []); setLoading(false) }
    catch(e) { setLoading(false) }
  }, [])
  useEffect(() => { load() }, [load])

  const filtered = search ? all.filter(u => (u.felhasznalonev + ' ' + (u.nev || '')).toLowerCase().includes(search.toLowerCase())) : all

  const create = async () => {
    if (!form.fnev || !form.pw) { setMsg('❌ Felhasználónév és jelszó kötelező'); return }
    if (form.pw.length < 6) { setMsg('❌ Legalább 6 karakter szükséges'); return }
    try {
      const res = await adminFetch('/api/admin/felhasznalo', { method: 'POST', body: JSON.stringify({ felhasznalonev: form.fnev, nev: form.nev, jelszo: form.pw, szerep: form.szerep }) })
      const d = await res.json()
      if (d.ok) { toast('✅ ' + form.fnev + ' létrehozva'); setForm({ fnev: '', nev: '', pw: '', szerep: 'admin' }); setMsg(''); load() }
      else setMsg('❌ ' + (d.error || 'Hiba'))
    } catch(e) { toast('API hiba', 'err') }
  }

  const toggleAktiv = async (id, aktiv) => {
    try {
      const res = await adminFetch('/api/admin/felhasznalo/' + id, { method: 'PATCH', body: JSON.stringify({ aktiv }) })
      const d = await res.json()
      if (d.ok) { toast(aktiv ? '✅ Aktiválva' : '⛔ Deaktiválva'); load() } else toast(d.error || 'Hiba', 'err')
    } catch(e) { toast('API hiba', 'err') }
  }

  const del = async (id, fnev) => {
    if (!confirm(fnev + ' törlése?')) return
    try {
      const res = await adminFetch('/api/admin/felhasznalo/' + id, { method: 'DELETE' })
      const d = await res.json()
      if (d.ok) { toast('🗑️ ' + fnev + ' törölve'); load() } else toast(d.error || 'Hiba', 'err')
    } catch(e) { toast('API hiba', 'err') }
  }

  const savePw = async () => {
    if (newPw.length < 6) { toast('Legalább 6 karakter', 'err'); return }
    try {
      const res = await adminFetch('/api/admin/felhasznalo/' + pwModal, { method: 'PATCH', body: JSON.stringify({ jelszo: newPw }) })
      const d = await res.json()
      if (d.ok) { toast('✅ Jelszó frissítve'); setPwModal(null); setNewPw('') } else toast(d.error || 'Hiba', 'err')
    } catch(e) { toast('API hiba', 'err') }
  }

  return (
    <div>
      <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 26, fontWeight: 700, marginBottom: 4 }}>Felhasználók</h1>
      <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)', marginBottom: 20 }}>Bejelentkezési fiókok – a /login oldalon tudnak belépni</p>

      <div style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)', borderRadius: 14, padding: '20px 24px', marginBottom: 20 }}>
        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, marginBottom: 16 }}>➕ Új felhasználó</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 8 }}>
          {[['Felhasználónév *', form.fnev, v => setForm(f => ({ ...f, fnev: v })), 'pl. kovacs.peter'],['Teljes név', form.nev, v => setForm(f => ({ ...f, nev: v })), 'Kovács Péter']].map(([l, v, set, p]) => (
            <div key={l}><label style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.06em', display: 'block', marginBottom: 5 }}>{l}</label><input className="inp inp-sm" value={v} onChange={e => set(e.target.value)} placeholder={p} autoComplete="off" /></div>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr auto', gap: 8, alignItems: 'flex-end' }}>
          <div><label style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.06em', display: 'block', marginBottom: 5 }}>Jelszó * (min 6)</label><input type="password" className="inp inp-sm" value={form.pw} onChange={e => setForm(f => ({ ...f, pw: e.target.value }))} placeholder="••••••••" autoComplete="new-password" /></div>
          <div><label style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.06em', display: 'block', marginBottom: 5 }}>Szerep</label>
            <select className="inp inp-sm" value={form.szerep} onChange={e => setForm(f => ({ ...f, szerep: e.target.value }))} style={{ cursor: 'pointer' }}>
              <option value="admin">⚙️ Admin</option>
              <option value="user">👤 User</option>
            </select>
          </div>
          <button className="btn btn-gold btn-sm" onClick={create}>Létrehozás</button>
        </div>
        {msg && <p style={{ fontSize: 12, color: '#ff6b82', marginTop: 8 }}>{msg}</p>}
      </div>

      <div style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)', borderRadius: 14, padding: '20px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700 }}>👤 Felhasználók</div>
          <span style={{ fontSize: 12, color: 'rgba(255,255,255,.35)', fontFamily: "'DM Mono',monospace" }}>{all.length} fő</span>
        </div>
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,.3)', fontSize: 13 }}>🔍</span>
          <input type="search" className="inp inp-sm" style={{ paddingLeft: 36 }} placeholder="Keresés…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {loading ? <div className="skel" style={{ height: 120, borderRadius: 10 }} /> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{['Felhasználónév','Teljes név','Szerep','Aktív','Létrehozva',''].map(h => <th key={h} style={{ fontSize: 11, fontWeight: 600, letterSpacing: '.07em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid rgba(255,255,255,.08)' }}>{h}</th>)}</tr></thead>
            <tbody>{filtered.map(u => (
              <tr key={u.id} style={{ borderBottom: '1px solid rgba(255,255,255,.05)' }}>
                <td style={{ padding: '10px 14px', fontFamily: "'DM Mono',monospace", fontSize: 13 }}>{u.felhasznalonev}</td>
                <td style={{ padding: '10px 14px', fontSize: 13, color: 'rgba(255,255,255,.75)' }}>{u.nev || '–'}</td>
                <td style={{ padding: '10px 14px' }}><span className={`tag ${u.szerep === 'admin' ? 'tag-gold' : 'tag-blue'}`}>{u.szerep === 'admin' ? '⚙️ Admin' : '👤 User'}</span></td>
                <td style={{ padding: '10px 14px' }}>
                  <button onClick={() => toggleAktiv(u.id, !u.aktiv)} className="btn btn-ghost btn-sm" style={{ padding: '4px 10px', fontSize: 11, color: u.aktiv ? '#4ade80' : '#ff6b82', borderColor: u.aktiv ? 'rgba(74,222,128,.3)' : 'rgba(255,107,130,.3)' }}>
                    {u.aktiv ? '✓ Aktív' : '✗ Inaktív'}
                  </button>
                </td>
                <td style={{ padding: '10px 14px', fontFamily: "'DM Mono',monospace", fontSize: 11, color: 'rgba(255,255,255,.4)' }}>{u.letrehozva ? new Date(u.letrehozva).toLocaleDateString('hu-HU') : '–'}</td>
                <td style={{ padding: '10px 14px', display: 'flex', gap: 5 }}>
                  <button className="btn btn-ghost btn-sm" title="Jelszó csere" onClick={() => { setPwModal(u.id); setNewPw('') }}>🔑</button>
                  <button className="btn btn-ghost btn-sm" title="Törlés" style={{ color: '#ff6b82' }} onClick={() => del(u.id, u.felhasznalonev)}>🗑️</button>
                </td>
              </tr>
            ))}</tbody>
          </table>
        )}
      </div>

      {pwModal && (
        <div onClick={e => e.target === e.currentTarget && setPwModal(null)} style={{ display: 'flex', position: 'fixed', inset: 0, zIndex: 400, background: 'rgba(4,9,15,.85)', backdropFilter: 'blur(8px)', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ background: '#0d1f3a', border: '1px solid rgba(255,255,255,.12)', borderRadius: 16, padding: 24, width: '100%', maxWidth: 360, margin: 16 }}>
            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, marginBottom: 16 }}>Jelszó csere</h3>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.06em', display: 'block', marginBottom: 5 }}>Új jelszó (min 6 kar.)</label>
              <input type="password" className="inp" value={newPw} onChange={e => setNewPw(e.target.value)} placeholder="••••••••" autoComplete="new-password" />
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-gold" style={{ flex: 1 }} onClick={savePw}>Mentés</button>
              <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setPwModal(null)}>Mégse</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

const SECTIONS = [
  { id: 'dashboard', label: '📊 Dashboard' },
  { id: 'tanarok', label: '👩‍🏫 Tanárok' },
  { id: 'szunetek', label: '🌙 Szünetek' },
  { id: 'felhasznalok', label: '👤 Felhasználók' },
]

export default function Admin() {
  const [authed, setAuthed] = useState(false)
  const [adminPw, setAdminPw] = useState('')
  const [loginError, setLoginError] = useState(false)
  const [section, setSection] = useState('dashboard')
  const [clock, setClock] = useState(new Date().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit', second: '2-digit' }))
  const { toast, Toasts } = useToastSimple()

  useEffect(() => {
    const t = setInterval(() => setClock(new Date().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit', second: '2-digit' })), 1000)
    return () => clearInterval(t)
  }, [])

  const doLogin = (e) => {
    e.preventDefault()
    fetch('/admin-login-check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Admin-Pw': adminPw }
    }).then(r => {
      if (r.ok) setAuthed(true)
      else setLoginError(true)
    }).catch(() => {
      // Fallback: cookie-based check via admin page redirect
      document.cookie = `ticky_admin_pw=${adminPw}; path=/; max-age=28800`
      setAuthed(true)
    })
  }

  const logout = () => {
    document.cookie = 'ticky_auth=; path=/; max-age=0'
    setAuthed(false); setAdminPw('')
  }

  if (!authed) {
    return (
      <div style={{ background: '#04090f', minHeight: '100vh', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundImage: 'radial-gradient(ellipse 70% 50% at 10% 0%,rgba(26,74,138,.4) 0%,transparent 55%),radial-gradient(ellipse 50% 40% at 90% 100%,rgba(200,151,42,.10) 0%,transparent 50%)' }}>
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: 2, zIndex: 200, background: 'linear-gradient(90deg,transparent,#c8972a 30%,#f0c76b 50%,#c8972a 70%,transparent)', boxShadow: '0 0 16px rgba(200,151,42,.3)' }} />
        <div style={{ width: '100%', maxWidth: 360, padding: '0 16px' }}>
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <a href="/" style={{ fontFamily: "'Playfair Display',serif", fontSize: 32, fontWeight: 700, color: 'white', display: 'inline-flex', alignItems: 'center', gap: 10 }}>
              <span className="pulse" style={{ width: 10, height: 10, borderRadius: '50%', background: '#c8972a', boxShadow: '0 0 10px #c8972a', display: 'inline-block' }} />Ticky
            </a>
            <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)', marginTop: 8 }}>Admin Panel</p>
          </div>
          <div className="glass" style={{ borderRadius: 16, padding: 32 }}>
            <form onSubmit={doLogin}>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,.35)', letterSpacing: '.07em', textTransform: 'uppercase', display: 'block', marginBottom: 8 }}>Jelszó</label>
                <input type="password" className="inp" placeholder="Admin jelszó…" autoFocus value={adminPw} onChange={e => { setAdminPw(e.target.value); setLoginError(false) }} style={{ borderColor: loginError ? 'rgba(232,51,74,.5)' : undefined }} />
              </div>
              {loginError && <div style={{ fontSize: 12, color: '#ff6b82', marginBottom: 12 }}>❌ Hibás jelszó</div>}
              <button type="submit" className="btn btn-gold" style={{ width: '100%', justifyContent: 'center', padding: 12, fontSize: 14 }}>Belépés →</button>
            </form>
            <p style={{ textAlign: 'center', marginTop: 14, fontSize: 11, color: 'rgba(255,255,255,.2)' }}>Jelszó: <span style={{ fontFamily: "'DM Mono',monospace", color: 'rgba(255,255,255,.3)' }}>ADMIN_PASSWORD</span> env var</p>
          </div>
          <p style={{ textAlign: 'center', marginTop: 14 }}><a href="/" style={{ fontSize: 12, color: 'rgba(255,255,255,.3)' }}>← Vissza a főoldalra</a></p>
        </div>
      </div>
    )
  }

  return (
    <div style={{ background: '#04090f', minHeight: '100vh', color: 'white', backgroundImage: 'radial-gradient(ellipse 70% 50% at 10% 0%,rgba(26,74,138,.4) 0%,transparent 55%),radial-gradient(ellipse 50% 40% at 90% 100%,rgba(200,151,42,.10) 0%,transparent 50%)' }}>
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: 2, zIndex: 200, background: 'linear-gradient(90deg,transparent,#c8972a 30%,#f0c76b 50%,#c8972a 70%,transparent)', boxShadow: '0 0 16px rgba(200,151,42,.3)' }} />

      <nav style={{ position: 'sticky', top: 0, zIndex: 100, height: 64, padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'rgba(4,9,15,.85)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(255,255,255,.07)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <a href="/" style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, color: 'white', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span className="pulse" style={{ width: 8, height: 8, borderRadius: '50%', background: '#c8972a', boxShadow: '0 0 8px #c8972a', display: 'inline-block' }} />Ticky
          </a>
          <span style={{ color: 'rgba(255,255,255,.2)' }}>·</span>
          <span style={{ fontSize: 13, color: 'rgba(255,255,255,.45)' }}>Admin</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 12, color: 'rgba(255,255,255,.3)', fontFamily: "'DM Mono',monospace" }}>{clock}</span>
          <button onClick={logout} className="btn btn-ghost btn-sm">Kilépés</button>
        </div>
      </nav>

      <div style={{ display: 'flex', minHeight: 'calc(100vh - 64px)' }}>
        <aside style={{ width: 220, flexShrink: 0, padding: '20px 12px', borderRight: '1px solid rgba(255,255,255,.07)', background: 'rgba(4,9,15,.4)' }}>
          {SECTIONS.map(s => (
            <button key={s.id} onClick={() => setSection(s.id)} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10, fontSize: 14, fontWeight: 500, cursor: 'pointer', transition: 'all .15s', marginBottom: 4, width: '100%', textAlign: 'left', background: section === s.id ? 'rgba(200,151,42,.12)' : 'transparent', border: section === s.id ? '1px solid rgba(200,151,42,.25)' : '1px solid transparent', color: section === s.id ? '#f0c76b' : 'rgba(255,255,255,.5)' }}>
              {s.label}
            </button>
          ))}
          <div style={{ borderTop: '1px solid rgba(255,255,255,.07)', marginTop: 16, paddingTop: 16 }}>
            {[['🏠 Termek live', '/termek'], ['📺 Kijelző', '/kijelzo'], ['🖨️ QR generátor', '/qr']].map(([l, h]) => (
              <a key={h} href={h} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10, fontSize: 14, fontWeight: 500, color: 'rgba(255,255,255,.5)', marginBottom: 4 }}>{l}</a>
            ))}
          </div>
        </aside>

        <main style={{ flex: 1, padding: 28, overflowY: 'auto', height: 'calc(100vh - 64px)' }}>
          {section === 'dashboard' && <Dashboard toast={toast} />}
          {section === 'tanarok' && <Tanarok toast={toast} />}
          {section === 'szunetek' && <Szunetek toast={toast} />}
          {section === 'felhasznalok' && <Felhasznalok toast={toast} />}
        </main>
      </div>
      <Toasts />
    </div>
  )
}
