import { useState, useEffect, useCallback } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { Layout } from '../components/Layout'

function toMin(t) { const [h, m] = t.split(':').map(Number); return h * 60 + m }
function isAktiv(k, v) { const c = new Date().getHours() * 60 + new Date().getMinutes(); return c >= toMin(k) && c <= toMin(v) }
function isMult(v) { return new Date().getHours() * 60 + new Date().getMinutes() > toMin(v) }

function groupByGrade(list) {
  const groups = {}
  list.forEach(name => {
    let gradeLabel = 'Egyéb'
    const match = name.match(/^(\d+)\./)
    if (match && !name.includes('_')) {
      const grade = parseInt(match[1])
      if (grade > 1) gradeLabel = grade + '. évfolyam'
    }
    if (!groups[gradeLabel]) groups[gradeLabel] = []
    groups[gradeLabel].push(name)
  })
  return Object.entries(groups).sort(([a], [b]) => {
    if (a === 'Egyéb') return 1
    if (b === 'Egyéb') return -1
    return parseInt(a) - parseInt(b)
  })
}

function OrarendView({ kod }) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    fetch(`/api/osztaly/${encodeURIComponent(kod)}/orarend`)
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false) })
      .catch(() => setLoading(false))
  }, [kod])

  if (loading) return <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}><div className="skel" style={{ width: 40, height: 40, borderRadius: '50%' }} /></div>

  if (data?.szunet) return (
    <div style={{ textAlign: 'center', padding: '40px 16px' }}>
      <div style={{ fontSize: 48, marginBottom: 12 }}>🌙</div>
      <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, fontWeight: 700, color: '#f0c76b', marginBottom: 8 }}>{data.szunet}</p>
      <p style={{ fontSize: 14, color: 'rgba(255,255,255,.5)' }}>Szünet idején nincs tanítás</p>
    </div>
  )

  if (!data?.orak?.length) return (
    <p style={{ textAlign: 'center', color: 'rgba(255,255,255,.3)', padding: '40px 0' }}>{data?.uzenet || 'Nincs mára órarend.'}</p>
  )

  return (
    <div>
      {data.orak.map((o, i) => {
        const ak = isAktiv(o.kezdes, o.vegzes), mu = isMult(o.vegzes)
        return (
          <div key={i} style={{ display: 'flex', alignItems: 'stretch', borderRadius: 12, overflow: 'hidden', border: ak ? '1px solid rgba(200,151,42,.5)' : '1px solid rgba(255,255,255,.07)', marginBottom: 7, background: ak ? 'rgba(200,151,42,.06)' : 'transparent', opacity: mu ? .38 : 1 }}>
            <div style={{ fontFamily: "'Playfair Display',serif", fontWeight: 700, fontSize: 17, color: ak ? '#f0c76b' : 'rgba(255,255,255,.2)', width: 38, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: ak ? 'rgba(200,151,42,.08)' : 'rgba(255,255,255,.03)', borderRight: `1px solid ${ak ? 'rgba(200,151,42,.2)' : 'rgba(255,255,255,.06)'}` }}>
              {o.ora_sorszam || i + 1}
            </div>
            <div style={{ flex: 1, padding: '9px 12px', minWidth: 0 }}>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,.28)', fontWeight: 500, marginBottom: 2 }}>{o.kezdes} – {o.vegzes}</div>
              {o.is_csoport ? (
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'rgba(255,255,255,.8)', marginBottom: 4 }}>{o.tantargy} <span style={{ fontSize: 11, color: 'rgba(255,255,255,.4)' }}>(csoportbontás)</span></div>
                  {o.csoportok?.map((cs, ci) => (
                    <div key={ci} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'rgba(255,255,255,.05)', borderRadius: 8, padding: '6px 10px', marginBottom: 4 }}>
                      <span style={{ color: '#f0c76b', fontWeight: 600, fontSize: 13 }}>{cs.terem}</span>
                      <span style={{ fontSize: 11, color: 'rgba(255,255,255,.6)' }}>{cs.tanar_nev || cs.tanar}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ color: '#f0c76b', fontWeight: 600, fontSize: 14 }}>{o.terem}</span>
                    <span style={{ fontSize: 13, color: 'rgba(255,255,255,.7)' }}>{o.tanar_nev || o.tanar}</span>
                  </div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,.4)', marginTop: 1 }}>{o.tantargy}</div>
                </div>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}

export default function Osztaly() {
  const { kod } = useParams()
  const navigate = useNavigate()
  const [list, setList] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [curKod, setCurKod] = useState(kod ? decodeURIComponent(kod) : '')

  useEffect(() => {
    fetch('/api/osztalyok').then(r => r.json()).then(d => { setList(d.osztalyok || []); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  const filtered = search ? list.filter(o => o.toLowerCase().includes(search.toLowerCase())) : list
  const grouped = groupByGrade(filtered)

  const onSelect = (val) => {
    setCurKod(val)
    if (val) navigate(`/osztaly/${encodeURIComponent(val)}`)
    else navigate('/osztaly')
  }

  if (kod) {
    const decodedKod = decodeURIComponent(kod)
    return (
      <Layout title={decodedKod}>
        <div style={{ maxWidth: '5xl', margin: '0 auto', padding: '32px 16px' }}>
          <div style={{ marginBottom: 24, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Link to="/osztaly" style={{ fontSize: 14, color: 'rgba(255,255,255,.5)' }}>← Vissza az összeshez</Link>
            <h2 style={{ fontSize: 20, fontWeight: 700 }}>{decodedKod} mai órái</h2>
          </div>
          <div className="glass" style={{ borderRadius: 24, padding: 16, minHeight: 300 }}>
            <OrarendView kod={decodedKod} />
          </div>
        </div>
      </Layout>
    )
  }

  return (
    <Layout title="Osztályok">
      <div style={{ maxWidth: '80rem', margin: '0 auto', padding: '32px 16px 60px' }}>
        {/* Search */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(28px,8vw,42px)', fontWeight: 700, marginBottom: 12 }}>Válassz osztályt</h1>
          <div style={{ maxWidth: 400, margin: '0 auto', position: 'relative' }}>
            <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Keresés (pl. 10.c)…"
              className="inp" style={{ textAlign: 'center', borderRadius: 99, padding: '12px 20px' }} />
          </div>
        </div>

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 60 }}>
            <div className="skel" style={{ width: 40, height: 40, borderRadius: '50%' }} />
          </div>
        ) : grouped.map(([grade, items]) => (
          <div key={grade} style={{ marginBottom: 32 }}>
            <p style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.2)', marginBottom: 12 }}>{grade}</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(100px,1fr))', gap: 10 }}>
              {items.map(o => (
                <Link key={o} to={`/osztaly/${encodeURIComponent(o)}`}
                  className="glass card-hover"
                  style={{ borderRadius: 14, padding: '16px 8px', textAlign: 'center', display: 'block', transition: 'all .2s' }}>
                  <span style={{ fontSize: 18, fontWeight: 500 }}>{o}</span>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Layout>
  )
}
