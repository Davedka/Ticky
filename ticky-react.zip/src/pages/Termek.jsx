import { useState, useEffect, useCallback } from 'react'
import { Layout, SzunetBanner, useToast } from '../components/Layout'

function calcPct(k, v) {
  const n = new Date(), c = n.getHours() * 60 + n.getMinutes()
  const [kh, km] = k.split(':').map(Number)
  const [vh, vm] = v.split(':').map(Number)
  return Math.min(100, Math.max(0, Math.round(((c - kh * 60 - km) / ((vh * 60 + vm) - (kh * 60 + km))) * 100)))
}

function RoomCard({ room, onOpen, delay }) {
  const sz = room.allapot === 'szabad'
  const a = room.aktualis
  const pillColor = sz ? '#4ade80' : '#ff6b82'
  const pillBg = sz ? 'rgba(26,138,74,.2)' : 'rgba(200,16,46,.2)'

  return (
    <div
      className="glass card-hover"
      style={{ borderRadius: 14, padding: 14, cursor: 'pointer', animationDelay: `${delay}ms` }}
      onClick={() => onOpen(room.terem_szam)}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 4 }}>
        <div>
          <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)' }}>Terem</p>
          <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(22px,5vw,28px)', fontWeight: 700, color: 'white', lineHeight: 1.1 }}>{room.terem_szam}</h2>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '3px 8px', borderRadius: 20, background: pillBg, border: `1px solid ${pillColor}44`, fontSize: 8, fontWeight: 700, color: pillColor, letterSpacing: '.04em', flexShrink: 0, marginTop: 2 }}>
          <span className="pulse" style={{ width: 5, height: 5, borderRadius: '50%', background: pillColor, display: 'inline-block' }} />
          {sz ? 'SZABAD' : 'FOGLALT'}
        </div>
      </div>
      {!sz && a ? (
        <div style={{ marginTop: 6 }}>
          <p style={{ fontSize: 11, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', color: 'rgba(255,255,255,.7)' }}>{a.tanar} · {a.osztaly}</p>
          <p style={{ fontSize: 10, color: 'rgba(255,255,255,.35)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.tantargy} · {a.kezdes}–{a.vegzes}</p>
          <div style={{ marginTop: 6, height: 3, borderRadius: 2, overflow: 'hidden', background: 'rgba(255,255,255,.1)' }}>
            <div style={{ height: '100%', width: `${calcPct(a.kezdes, a.vegzes)}%`, background: 'linear-gradient(90deg,#e8334a,#ff6b82)' }} />
          </div>
        </div>
      ) : (
        <p style={{ fontSize: 11, marginTop: 6, color: 'rgba(255,255,255,.3)' }}>Nincs óra</p>
      )}
    </div>
  )
}

function Modal({ szam, onClose }) {
  const [data, setData] = useState(null)

  useEffect(() => {
    if (!szam) return
    fetch(`/api/terem/${encodeURIComponent(szam)}`).then(r => r.json()).then(setData).catch(() => {})
  }, [szam])

  if (!szam) return null

  const sz = data?.allapot === 'szabad' || !data
  const a = data?.aktualis
  const pillColor = sz ? '#4ade80' : '#ff6b82'
  const pillBg = sz ? 'rgba(26,138,74,.2)' : 'rgba(200,16,46,.2)'

  return (
    <div onClick={(e) => e.target === e.currentTarget && onClose()} style={{ display: 'flex', position: 'fixed', inset: 0, zIndex: 500, background: 'rgba(6,15,30,.75)', backdropFilter: 'blur(8px)', alignItems: 'flex-end', justifyContent: 'center', padding: 16 }}>
      <div className="glass" style={{ width: '100%', maxWidth: 420, borderRadius: 20, overflow: 'hidden' }}>
        <div style={{ padding: '20px 20px 8px' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16 }}>
            <div>
              <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', marginBottom: 2 }}>Terem</p>
              <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: 36, fontWeight: 700, color: 'white', lineHeight: 1 }}>{szam}</h2>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 12px', borderRadius: 20, background: pillBg, border: `1px solid ${pillColor}55`, fontSize: 10, fontWeight: 700, color: pillColor }}>
                <span className="pulse" style={{ width: 5, height: 5, borderRadius: '50%', background: pillColor, display: 'inline-block' }} />
                {data ? (sz ? 'SZABAD' : 'FOGLALT') : '–'}
              </div>
              <button onClick={onClose} style={{ background: 'rgba(255,255,255,.08)', border: 'none', color: 'rgba(255,255,255,.5)', width: 32, height: 32, borderRadius: 8, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>✕</button>
            </div>
          </div>
          {data?.szunet ? (
            <div style={{ textAlign: 'center', padding: '16px 0' }}>
              <div style={{ fontSize: 36, marginBottom: 8 }}>🌙</div>
              <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, color: '#f0c76b', marginBottom: 4 }}>{data.szunet}</p>
              <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)' }}>Szünet idején nincs tanítás</p>
            </div>
          ) : !data ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div className="skel" style={{ height: 12, width: '40%' }} />
              <div className="skel" style={{ height: 20, width: '70%' }} />
            </div>
          ) : sz ? (
            <div style={{ textAlign: 'center', padding: '16px 0' }}>
              <span style={{ fontSize: 36, display: 'block', marginBottom: 8 }}>✅</span>
              <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, color: '#4ade80' }}>Szabad terem</p>
              <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)', marginTop: 4 }}>Nincs aktív foglalás</p>
            </div>
          ) : a ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.35)', marginBottom: 2 }}>Tanár</p>
                <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 20, fontWeight: 700, color: 'white' }}>{a.tanar_nev || a.tanar}</p>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                {[['Osztály', a.osztaly], ['Tantárgy', a.tantargy]].map(([l, v]) => (
                  <div key={l}>
                    <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.35)', marginBottom: 2 }}>{l}</p>
                    <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 17, fontWeight: 700, color: 'white' }}>{v}</p>
                  </div>
                ))}
              </div>
              <div>
                <div style={{ height: 5, borderRadius: 3, overflow: 'hidden', background: 'rgba(255,255,255,.1)' }}>
                  <div style={{ height: '100%', width: `${calcPct(a.kezdes, a.vegzes)}%`, background: 'linear-gradient(90deg,#e8334a,#ff6b82)' }} />
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 5, fontSize: 11, color: 'rgba(255,255,255,.35)' }}>
                  <span>{a.kezdes}</span>
                  <span style={{ color: '#ff6b82', fontWeight: 600 }}>még {a.perc_maradt} perc</span>
                  <span>{a.vegzes}</span>
                </div>
              </div>
            </div>
          ) : null}
          {data?.kovetkezo && (
            <div style={{ marginTop: 12, padding: '12px 14px', borderRadius: 10, background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.08)' }}>
              <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', marginBottom: 6 }}>Következő</p>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap' }}>
                <span style={{ fontSize: 13, color: 'rgba(255,255,255,.7)' }}>{data.kovetkezo.tanar} · {data.kovetkezo.osztaly} · {data.kovetkezo.tantargy}</span>
                <span style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', whiteSpace: 'nowrap' }}>{data.kovetkezo.kezdes}–{data.kovetkezo.vegzes}</span>
              </div>
            </div>
          )}
        </div>
        <div style={{ padding: '12px 20px', borderTop: '1px solid rgba(255,255,255,.08)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <a href={`/terem/${szam}`} style={{ fontSize: 13, fontWeight: 500, color: '#f0c76b' }}>Napirend nézet →</a>
          <span style={{ fontFamily: "'Playfair Display',serif", color: 'rgba(255,255,255,.2)', fontSize: 13, fontWeight: 700 }}>Ticky</span>
        </div>
      </div>
    </div>
  )
}

export default function Termek() {
  const [rooms, setRooms] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('mind')
  const [search, setSearch] = useState('')
  const [modal, setModal] = useState(null)
  const [szunet, setSzunet] = useState(null)
  const [ido, setIdo] = useState('')
  const [weekend, setWeekend] = useState(false)

  const load = useCallback(async () => {
    try {
      const d = await fetch('/api/termek?allapot=1').then(r => r.json())
      if (d.error) return
      setRooms((d.termek || []).map(r => ({ ...r, allapot: r.allapot ?? 'szabad', aktualis: r.aktualis ?? null })))
      setSzunet(d.szunet || null)
      setWeekend(d.nap === 0)
      setIdo(new Date().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' }))
      setLoading(false)
    } catch(e) { setLoading(false) }
  }, [])

  useEffect(() => { load(); const t = setInterval(load, 60000); return () => clearInterval(t) }, [load])

  const filtered = rooms
    .filter(r => filter === 'mind' || r.allapot === filter)
    .filter(r => !search || r.terem_szam.toLowerCase().includes(search.toLowerCase()))

  const fo = rooms.filter(r => r.allapot === 'foglalt').length
  const sz = rooms.filter(r => r.allapot === 'szabad').length

  const filterBtns = [
    { key: 'mind', label: `Összes ${rooms.length}`, cls: 'active' },
    { key: 'szabad', label: `Szabad ${sz}`, cls: 'active-szabad', dot: '#4ade80' },
    { key: 'foglalt', label: `Foglalt ${fo}`, cls: 'active-foglalt', dot: '#ff6b82' },
  ]

  return (
    <Layout title="Összes terem">
      {/* Weekend/szünet banners */}
      {weekend && !szunet && (
        <div style={{ maxWidth: '80rem', margin: '0 auto', padding: '16px 16px 0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 16px', borderRadius: 12, background: 'rgba(200,151,42,.10)', border: '1px solid rgba(200,151,42,.25)', color: '#f0c76b', fontSize: 13 }}>
            🌙 Hétvége – az órarendek hétfőn frissülnek.
          </div>
        </div>
      )}
      {szunet && (
        <div style={{ maxWidth: '80rem', margin: '0 auto', padding: '12px 16px 0' }}>
          <SzunetBanner szunet={szunet} />
        </div>
      )}

      {/* Filter bar */}
      <div style={{ maxWidth: '80rem', margin: '0 auto', padding: '16px 16px 12px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            {filterBtns.map(b => (
              <button key={b.key} onClick={() => setFilter(b.key)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 7, padding: '8px 14px', borderRadius: 10,
                  fontSize: 13, fontWeight: 500, cursor: 'pointer', transition: 'all .15s', whiteSpace: 'nowrap',
                  border: filter === b.key
                    ? (b.key === 'szabad' ? '1px solid rgba(26,138,74,.4)' : b.key === 'foglalt' ? '1px solid rgba(200,16,46,.4)' : '1px solid rgba(255,255,255,.25)')
                    : '1px solid rgba(255,255,255,.12)',
                  background: filter === b.key
                    ? (b.key === 'szabad' ? 'rgba(26,138,74,.2)' : b.key === 'foglalt' ? 'rgba(200,16,46,.2)' : 'rgba(255,255,255,.12)')
                    : 'rgba(255,255,255,.05)',
                  color: filter === b.key
                    ? (b.key === 'szabad' ? '#4ade80' : b.key === 'foglalt' ? '#ff6b82' : 'white')
                    : 'rgba(255,255,255,.5)'
                }}>
                {b.dot && <span style={{ width: 7, height: 7, borderRadius: '50%', background: b.dot, display: 'inline-block', flexShrink: 0 }} />}
                {b.label}
              </button>
            ))}
            <button onClick={load} style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', borderRadius: 10, fontSize: 12, color: 'rgba(255,255,255,.4)', border: '1px solid rgba(255,255,255,.12)', background: 'transparent', cursor: 'pointer' }}>
              🔄 {ido}
            </button>
          </div>
          <div style={{ position: 'relative' }}>
            <span style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,.3)', fontSize: 13 }}>🔍</span>
            <input type="search" className="inp" style={{ paddingLeft: 32 }} placeholder="Terem száma…" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>
      </div>

      {/* Grid */}
      <main style={{ maxWidth: '80rem', margin: '0 auto', padding: '0 16px 60px' }}>
        {loading ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 10 }}>
            {Array(8).fill(0).map((_, i) => <div key={i} className="skel" style={{ height: 120, borderRadius: 14 }} />)}
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0' }}>
            <span style={{ fontSize: 40, display: 'block', marginBottom: 10 }}>🔍</span>
            <p style={{ color: 'rgba(255,255,255,.6)', fontWeight: 600 }}>Nincs találat</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 10 }}>
            {filtered.map((r, i) => <RoomCard key={r.terem_szam} room={r} onOpen={setModal} delay={i * 20} />)}
          </div>
        )}
      </main>

      {modal && <Modal szam={modal} onClose={() => setModal(null)} />}
    </Layout>
  )
}
