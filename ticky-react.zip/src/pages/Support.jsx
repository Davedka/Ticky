import { useState } from 'react'
import { Layout } from '../components/Layout'

export default function Support() {
  const [form, setForm] = useState({ nev: '', email: '', uzenet: '' })
  const [sent, setSent] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    window.location.href = `mailto:support@ticky.hu?subject=Ticky Support – ${encodeURIComponent(form.nev)}&body=${encodeURIComponent(form.uzenet)}`
    setSent(true)
  }

  return (
    <Layout title="Support">
      <div style={{ maxWidth: 560, margin: '0 auto', padding: '40px 16px 60px' }}>
        <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 36, fontWeight: 700, marginBottom: 8 }}>Support</h1>
        <p style={{ fontSize: 14, color: 'rgba(255,255,255,.45)', marginBottom: 32 }}>Kérdés, probléma, vagy javaslat? Írj nekünk!</p>
        {sent ? (
          <div className="glass" style={{ borderRadius: 16, padding: 32, textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>✅</div>
            <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 20, fontWeight: 700, color: '#4ade80' }}>Köszönjük!</p>
            <p style={{ fontSize: 13, color: 'rgba(255,255,255,.45)', marginTop: 8 }}>A levelező kliens megnyílt az üzeneteddel.</p>
          </div>
        ) : (
          <div className="glass" style={{ borderRadius: 16, padding: 28 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {[['nev', 'Neved', 'text', 'Kovács Péter'], ['email', 'Email', 'email', 'pe@email.hu']].map(([k, l, t, p]) => (
                <div key={k}>
                  <label style={{ fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,.35)', letterSpacing: '.07em', textTransform: 'uppercase', display: 'block', marginBottom: 7 }}>{l}</label>
                  <input type={t} className="inp" placeholder={p} value={form[k]} onChange={e => setForm(f => ({ ...f, [k]: e.target.value }))} />
                </div>
              ))}
              <div>
                <label style={{ fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,.35)', letterSpacing: '.07em', textTransform: 'uppercase', display: 'block', marginBottom: 7 }}>Üzenet</label>
                <textarea className="inp" rows={5} placeholder="Írd le a problémát vagy javaslatot…" value={form.uzenet} onChange={e => setForm(f => ({ ...f, uzenet: e.target.value }))} style={{ resize: 'vertical' }} />
              </div>
              <button className="btn btn-gold" style={{ justifyContent: 'center', padding: 13 }} onClick={handleSubmit}>✉️ Üzenet küldése</button>
            </div>
            <p style={{ marginTop: 16, fontSize: 12, color: 'rgba(255,255,255,.3)', textAlign: 'center' }}>
              Vagy nyiss egy <a href="https://github.com/Davedka/Ticky/issues/new" target="_blank" rel="noopener" style={{ color: '#f0c76b' }}>GitHub issue-t</a>
            </p>
          </div>
        )}
      </div>
    </Layout>
  )
}
