import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'

const NAP_NEVEK = ['Hétvége','Hétfő','Kedd','Szerda','Csütörtök','Péntek','Szombat']

function maiNap() { const d = new Date().getDay(); return d === 0 ? 0 : d === 6 ? 0 : d }
function aktualisIdo() { const n = new Date(); return n.getHours().toString().padStart(2,'0') + ':' + n.getMinutes().toString().padStart(2,'0') }

export default function Home() {
  const [ido, setIdo] = useState(aktualisIdo())
  const nap = maiNap()

  useEffect(() => {
    const t = setInterval(() => setIdo(aktualisIdo()), 30000)
    return () => clearInterval(t)
  }, [])

  return (
    <div style={{
      background: '#060f1e', minHeight: '100vh', color: 'white',
      backgroundImage: 'radial-gradient(ellipse 70% 55% at 15% 10%,rgba(26,74,138,.55) 0%,transparent 60%),radial-gradient(ellipse 50% 45% at 85% 85%,rgba(200,151,42,.18) 0%,transparent 55%),radial-gradient(ellipse 60% 30% at 30% 90%,rgba(7,29,58,.8) 0%,transparent 50%)'
    }}>
      <div className="top-line" />
      <div style={{ position:'fixed',inset:0,pointerEvents:'none',zIndex:0,backgroundImage:'linear-gradient(rgba(255,255,255,.02) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.02) 1px,transparent 1px)',backgroundSize:'40px 40px' }} />

      {/* Sidebar */}
      <div className="ticky-sidebar">
        <a href="https://esemenynaptar.onrender.com/" target="_blank" rel="noopener" className="tsb-item" data-label="Eseménynaptár">📅</a>
        <div className="tsb-divider" />
        <Link to="/support" className="tsb-item" data-label="Support">✉️</Link>
        <a href="https://github.com/Davedka/Ticky/issues/new" target="_blank" rel="noopener" className="tsb-item" data-label="Bug report">🐛</a>
      </div>

      {/* Navbar */}
      <nav className="ticky-navbar">
        <Link to="/" className="tn-brand">
          <span className="pulse" style={{ width:8,height:8,borderRadius:'50%',background:'#c8972a',boxShadow:'0 0 10px #c8972a',display:'inline-block',flexShrink:0 }} />
          Ticky
        </Link>
        <div className="tn-links" style={{ display:'flex',alignItems:'center',gap:2 }}>
          <Link to="/termek" className="tn-link">Termek</Link>
          <Link to="/tanar" className="tn-link">Tanár</Link>
          <Link to="/osztaly" className="tn-link">Osztály</Link>
          <Link to="/qr" className="tn-link">QR</Link>
          <Link to="/kijelzo" className="tn-link">Kijelző</Link>
          <Link to="/admin" className="tn-link gold">⚙️ Admin</Link>
        </div>
      </nav>

      {/* Main */}
      <div style={{ position:'relative',zIndex:10,padding:'48px 20px 60px',maxWidth:680,margin:'0 auto' }}>
        {/* Hero */}
        <div className="fade-up" style={{ textAlign:'center',marginBottom:40 }}>
          <h1 style={{ fontFamily:"'Playfair Display',serif",fontSize:'clamp(56px,16vw,80px)',fontWeight:700,lineHeight:1,letterSpacing:-2,color:'white' }}>Ticky</h1>
          <p style={{ fontSize:14,color:'rgba(255,255,255,.45)',marginTop:10 }}>Digitális terem-azonosító rendszer</p>
          <div style={{ display:'inline-flex',alignItems:'center',gap:8,marginTop:16,fontSize:12,fontWeight:500,color:'#4ade80' }}>
            <span className="pulse" style={{ width:7,height:7,borderRadius:'50%',background:'#4ade80',display:'inline-block',flexShrink:0 }} />
            {NAP_NEVEK[nap > 0 ? new Date().getDay() : 0]} · {ido} · Aktív
          </div>
        </div>

        {/* Összes terem */}
        <div className="fade-up-2" style={{ marginBottom:10 }}>
          <div className="gold-line" />
          <Link to="/termek" className="glass card-hover" style={{ display:'flex',alignItems:'center',justifyContent:'space-between',gap:16,padding:'20px 22px',borderRadius:'0 0 14px 14px',borderTop:'none' }}>
            <div>
              <p style={{ fontSize:10,fontWeight:600,letterSpacing:'.1em',textTransform:'uppercase',color:'rgba(255,255,255,.35)',marginBottom:4 }}>Élő nézet</p>
              <h2 style={{ fontFamily:"'Playfair Display',serif",fontSize:21,fontWeight:700,color:'white' }}>Összes terem</h2>
              <p style={{ fontSize:13,color:'rgba(255,255,255,.45)',marginTop:2 }}>Szabad &amp; foglalt termek valós időben</p>
            </div>
            <span style={{ fontSize:30 }}>🏫</span>
          </Link>
        </div>

        {/* 3-col grid */}
        <div className="fade-up-3" style={{ display:'grid',gridTemplateColumns:'repeat(3,minmax(0,1fr))',gap:10,marginBottom:10 }}>
          {[
            { to:'/tanar', emoji:'👩‍🏫', title:'Tanár kereső', sub:'Hol van most?' },
            { to:'/osztaly', emoji:'🎓', title:'Osztály nézet', sub:'Hol van most?' },
            { to:'/qr', emoji:'🖨️', title:'QR Generátor', sub:'Nyomtatható kódok' },
          ].map(card => (
            <div key={card.to}>
              <div className="gold-line" />
              <Link to={card.to} className="glass card-hover" style={{ display:'flex',flexDirection:'column',alignItems:'flex-start',padding:18,borderRadius:'0 0 14px 14px',borderTop:'none',height:'100%' }}>
                <span style={{ fontSize:24,display:'block',marginBottom:8 }}>{card.emoji}</span>
                <h3 style={{ fontFamily:"'Playfair Display',serif",fontSize:17,fontWeight:700,color:'white',lineHeight:1.15 }}>{card.title}</h3>
                <p style={{ fontSize:12,color:'rgba(255,255,255,.4)',marginTop:3 }}>{card.sub}</p>
              </Link>
            </div>
          ))}
        </div>

        <p className="fade-up-4" style={{ textAlign:'center',fontSize:11,color:'rgba(255,255,255,.18)',marginTop:24 }}>Ticky v1.0 · Render · Supabase · PHP</p>
      </div>
    </div>
  )
}
