import { useState, useEffect, useRef } from 'react'
import { Layout } from '../components/Layout'

export default function QR() {
  const [termek, setTermek] = useState([])
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState([])
  const [loading, setLoading] = useState(true)
  const printRef = useRef()

  useEffect(() => {
    fetch('/api/termek').then(r => r.json()).then(d => { setTermek(d.termek || []); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  const filtered = termek.filter(t => !search || t.terem_szam.toLowerCase().includes(search.toLowerCase()))
  const toggleSelect = (sz) => setSelected(s => s.includes(sz) ? s.filter(x => x !== sz) : [...s, sz])
  const selectAll = () => setSelected(filtered.map(t => t.terem_szam))
  const clearAll = () => setSelected([])

  const printSzamok = selected.length ? selected : filtered.map(t => t.terem_szam)

  const handlePrint = () => {
    const w = window.open('', '_blank')
    w.document.write(`<!DOCTYPE html><html><head><title>Ticky QR Kódok</title>
    <style>
      body{font-family:'DM Sans',sans-serif;background:white;color:#1a1a2e;margin:0;padding:20px;}
      .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;page-break-inside:avoid;}
      .card{border:2px solid #1a4a8a;border-radius:12px;padding:16px;text-align:center;page-break-inside:avoid;}
      .room{font-size:32px;font-weight:700;color:#1a1a2e;margin-bottom:8px;font-family:serif;}
      .qr{width:120px;height:120px;margin:0 auto 8px;background:#f0f0f0;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:12px;color:#666;}
      .url{font-size:10px;color:#666;word-break:break-all;}
      @media print{body{padding:0;}.grid{gap:10px;}}
    </style></head><body>
    <h2 style="text-align:center;margin-bottom:20px;font-size:18px;color:#1a4a8a;">Ticky – Terem QR Kódok</h2>
    <div class="grid">
    ${printSzamok.map(sz => `<div class="card">
      <div class="room">${sz}</div>
      <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(window.location.origin + '/terem/' + sz)}" width="120" height="120" style="border-radius:8px;margin-bottom:8px;" />
      <div class="url">${window.location.origin}/terem/${sz}</div>
    </div>`).join('')}
    </div>
    <script>window.onload=function(){window.print();window.close();}<\/script>
    </body></html>`)
    w.document.close()
  }

  return (
    <Layout title="QR Generátor">
      <div style={{ maxWidth: 800, margin: '0 auto', padding: '32px 16px 60px' }}>
        <div style={{ marginBottom: 24 }}>
          <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 32, fontWeight: 700, marginBottom: 4 }}>QR Generátor</h1>
          <p style={{ fontSize: 14, color: 'rgba(255,255,255,.45)' }}>Válaszd ki a termeket, majd nyomtasd ki a QR kódokat</p>
        </div>

        {/* Controls */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center' }}>
          <input type="search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Keresés…" className="inp inp-sm" style={{ maxWidth: 200 }} />
          <button onClick={selectAll} className="btn btn-ghost btn-sm">Összes</button>
          <button onClick={clearAll} className="btn btn-ghost btn-sm">Egyik sem</button>
          <button onClick={handlePrint} className="btn btn-gold" style={{ marginLeft: 'auto' }}>
            🖨️ Nyomtatás ({printSzamok.length} terem)
          </button>
        </div>

        {/* Grid */}
        {loading ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(140px,1fr))', gap: 10 }}>
            {Array(12).fill(0).map((_, i) => <div key={i} className="skel" style={{ height: 180, borderRadius: 12 }} />)}
          </div>
        ) : (
          <div ref={printRef} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(140px,1fr))', gap: 10 }}>
            {filtered.map(t => {
              const sel = selected.includes(t.terem_szam)
              const url = `${window.location.origin}/terem/${t.terem_szam}`
              return (
                <div key={t.terem_szam} onClick={() => toggleSelect(t.terem_szam)} className="glass card-hover" style={{ borderRadius: 12, padding: 14, textAlign: 'center', cursor: 'pointer', border: sel ? '1.5px solid rgba(200,151,42,.6)' : '1px solid rgba(255,255,255,.10)', background: sel ? 'rgba(200,151,42,.08)' : 'rgba(255,255,255,.04)' }}>
                  <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, fontWeight: 700, color: sel ? '#f0c76b' : 'white', marginBottom: 8 }}>{t.terem_szam}</div>
                  <img src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(url)}`} alt={t.terem_szam} width={100} height={100} style={{ borderRadius: 8, display: 'block', margin: '0 auto 8px' }} loading="lazy" />
                  <div style={{ fontSize: 9, color: 'rgba(255,255,255,.3)', wordBreak: 'break-all' }}>{url}</div>
                  {sel && <div style={{ marginTop: 6, fontSize: 11, color: '#f0c76b', fontWeight: 600 }}>✓ Kiválasztva</div>}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </Layout>
  )
}
