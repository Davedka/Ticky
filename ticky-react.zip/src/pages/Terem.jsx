import { useState, useEffect, useCallback } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Layout } from '../components/Layout'

function toMin(t) { const [h, m] = t.split(':').map(Number); return h * 60 + m }
function nowMin() { const n = new Date(); return n.getHours() * 60 + n.getMinutes() }
function isAktiv(k, v) { const c = nowMin(); return c >= toMin(k) && c <= toMin(v) }
function isMult(v) { return nowMin() > toMin(v) }
function calcPct(k, v) { return Math.min(100, Math.max(0, Math.round(((nowMin() - toMin(k)) / (toMin(v) - toMin(k))) * 100))) }

const NAP = {1:'H',2:'K',3:'Sze',4:'Cs',5:'P'}
const START = 7*60+30, END = 14*60+30, PPM = 1.7
const H = (END - START) * PPM

function topPx(m) { return Math.max(0, (m - START) * PPM) }
function maiNap() { const d = new Date().getDay(); return d === 0 || d === 6 ? 0 : d }

export default function Terem() {
  const { szam } = useParams()
  const terem = szam?.toUpperCase()
  const [status, setStatus] = useState(null)
  const [hetData, setHetData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [ido, setIdo] = useState(new Date().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' }))

  const fetchStatus = useCallback(async () => {
    try {
      const d = await fetch(`/api/terem/${encodeURIComponent(terem)}`).then(r => r.json())
      if (!d.error) setStatus(d)
    } catch(e) {}
    setIdo(new Date().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' }))
  }, [terem])

  const fetchTimetable = useCallback(async () => {
    try {
      const d = await fetch(`/api/napirend/${encodeURIComponent(terem)}?nap=heten`).then(r => r.json())
      if (!d.error) {
        const het = {}
        ;(d.het || []).forEach(nd => { het[nd.nap] = nd.orak || [] })
        setHetData(het)
        setLoading(false)
      }
    } catch(e) { setLoading(false) }
  }, [terem])

  useEffect(() => {
    fetchStatus(); fetchTimetable()
    const t1 = setInterval(fetchStatus, 60000)
    const t2 = setInterval(fetchTimetable, 5 * 60000)
    return () => { clearInterval(t1); clearInterval(t2) }
  }, [fetchStatus, fetchTimetable])

  const sz = status?.allapot === 'szabad' || !status
  const a = status?.aktualis
  const mai = maiNap()

  const bgStyle = status?.szunet ? {} : sz
    ? { backgroundImage: 'radial-gradient(ellipse 70% 55% at 15% 10%,rgba(26,138,74,.38) 0%,transparent 60%),radial-gradient(ellipse 50% 45% at 85% 85%,rgba(26,74,138,.2) 0%,transparent 55%)' }
    : { backgroundImage: 'radial-gradient(ellipse 70% 55% at 15% 10%,rgba(200,16,46,.32) 0%,transparent 60%),radial-gradient(ellipse 50% 45% at 85% 85%,rgba(200,151,42,.12) 0%,transparent 55%)' }

  const pillStyle = sz
    ? { bg: 'rgba(26,138,74,.25)', border: 'rgba(26,138,74,.4)', color: '#4ade80', dot: '#4ade80', text: 'SZABAD' }
    : { bg: 'rgba(200,16,46,.25)', border: 'rgba(200,16,46,.4)', color: '#ff6b82', dot: '#ff6b82', text: 'FOGLALT' }

  return (
    <div style={{ background: '#060f1e', minHeight: '100vh', color: 'white', ...bgStyle, transition: 'background-image .6s' }}>
      <div className="top-line" />
      <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0, backgroundImage: 'linear-gradient(rgba(255,255,255,.018) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.018) 1px,transparent 1px)', backgroundSize: '40px 40px' }} />
      <Layout title={terem}>
        <div style={{ position: 'relative', zIndex: 10, maxWidth: 440, margin: '0 auto', padding: '24px 16px 0' }}>
          <div className="glass" style={{ borderRadius: 18, overflow: 'hidden' }}>
            <div style={{ padding: '14px 20px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,.05)' }}>
              <a href="/" style={{ fontFamily: "'Playfair Display',serif", color: 'rgba(255,255,255,.35)', fontSize: 14, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6, paddingBottom: 12 }}>
                <span className="pulse" style={{ width: 6, height: 6, borderRadius: '50%', background: '#c8972a', boxShadow: '0 0 6px #c8972a', display: 'inline-block' }} />Ticky
              </a>
              <span style={{ fontSize: 11, color: 'rgba(255,255,255,.25)', paddingBottom: 12 }}>Terem nézet</span>
            </div>
            <div style={{ padding: '18px 20px', borderBottom: '1px solid rgba(255,255,255,.08)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
              <div>
                <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', marginBottom: 4 }}>Terem</p>
                <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(40px,12vw,56px)', fontWeight: 700, color: 'white', lineHeight: 1, letterSpacing: -1 }}>{terem}</h1>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '8px 14px', borderRadius: 99, fontSize: 12, fontWeight: 600, background: pillStyle.bg, border: `1px solid ${pillStyle.border}`, color: pillStyle.color, flexShrink: 0 }}>
                <span className="pulse" style={{ width: 7, height: 7, borderRadius: '50%', background: pillStyle.dot, display: 'inline-block' }} />
                {status ? pillStyle.text : 'Betöltés…'}
              </div>
            </div>
            <div style={{ padding: 20, minHeight: 100 }}>
              {!status ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div className="skel" style={{ height: 12, width: '40%' }} />
                  <div className="skel" style={{ height: 24, width: '60%' }} />
                  <div className="skel" style={{ height: 12 }} />
                </div>
              ) : status.szunet ? (
                <div style={{ textAlign: 'center', padding: '16px 0' }}>
                  <div style={{ fontSize: 40, marginBottom: 10 }}>🌙</div>
                  <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, color: '#f0c76b', marginBottom: 4 }}>{status.szunet}</p>
                  <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)' }}>Szünet idején nincs tanítás</p>
                </div>
              ) : sz ? (
                <div>
                  <div style={{ textAlign: 'center', padding: '16px 0' }}>
                    <span style={{ fontSize: 40, display: 'block', marginBottom: 10 }}>✅</span>
                    <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 20, fontWeight: 700, color: '#4ade80', marginBottom: 4 }}>Szabad terem</p>
                    <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)' }}>Nincs aktív foglalás</p>
                  </div>
                  {status.kovetkezo && (
                    <div style={{ marginTop: 14, padding: '12px 14px', borderRadius: 10, background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.07)' }}>
                      <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.25)', marginBottom: 4 }}>Következő óra</p>
                      <p style={{ fontSize: 13, color: 'rgba(255,255,255,.7)' }}>{status.kovetkezo.tanar} · {status.kovetkezo.osztaly} · {status.kovetkezo.tantargy}</p>
                      <p style={{ fontSize: 11, color: 'rgba(255,255,255,.35)', marginTop: 2 }}>{status.kovetkezo.kezdes}–{status.kovetkezo.vegzes}</p>
                    </div>
                  )}
                </div>
              ) : a ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  <div>
                    <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', marginBottom: 2 }}>Tanár</p>
                    <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, fontWeight: 700, color: 'white', lineHeight: 1.2 }}>{a.tanar_nev || a.tanar}</p>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                    {[['Osztály', a.osztaly], ['Tantárgy', a.tantargy]].map(([l, v]) => (
                      <div key={l}><p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', marginBottom: 2 }}>{l}</p><p style={{ fontFamily: "'Playfair Display',serif", fontSize: 17, fontWeight: 700, color: 'white' }}>{v}</p></div>
                    ))}
                  </div>
                  <div>
                    <div style={{ height: 5, borderRadius: 3, overflow: 'hidden', background: 'rgba(255,255,255,.08)' }}>
                      <div style={{ height: '100%', width: `${calcPct(a.kezdes, a.vegzes)}%`, background: 'linear-gradient(90deg,#e8334a,#ff6b82)', transition: 'width .6s' }} />
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 5, fontSize: 11, color: 'rgba(255,255,255,.35)' }}>
                      <span>{a.kezdes}</span>
                      <span style={{ color: '#ff6b82', fontWeight: 600 }}>még {a.perc_maradt} perc</span>
                      <span>{a.vegzes}</span>
                    </div>
                  </div>
                  {status.kovetkezo && (
                    <div style={{ padding: '12px 14px', borderRadius: 10, background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.07)' }}>
                      <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.25)', marginBottom: 4 }}>Következő</p>
                      <p style={{ fontSize: 13, color: 'rgba(255,255,255,.7)' }}>{status.kovetkezo.tanar} · {status.kovetkezo.osztaly} · {status.kovetkezo.tantargy} · {status.kovetkezo.kezdes}–{status.kovetkezo.vegzes}</p>
                    </div>
                  )}
                </div>
              ) : null}
            </div>
            <div style={{ padding: '12px 20px', borderTop: '1px solid rgba(255,255,255,.08)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 12, color: 'rgba(255,255,255,.28)' }}>{ido}</span>
              <button onClick={() => { fetchStatus(); fetchTimetable() }} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', borderRadius: 8, fontSize: 12, color: 'rgba(255,255,255,.4)', border: '1px solid rgba(255,255,255,.10)', background: 'transparent', cursor: 'pointer' }}>🔄 Frissít</button>
            </div>
          </div>
        </div>

        {/* Timetable header */}
        <div style={{ position: 'relative', zIndex: 10, maxWidth: 600, margin: '28px auto 10px', padding: '0 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,.28)' }}>Heti órarend</p>
          <Link to={`/terem/${terem}/nap`} style={{ fontSize: 12, color: '#f0c76b', fontWeight: 500 }}>Teljes nézet →</Link>
        </div>

        {/* Timetable */}
        {loading ? (
          <div style={{ maxWidth: 600, margin: '0 auto', padding: '0 16px', display: 'flex', gap: 5 }}>
            {[38, ...Array(5).fill('1fr')].map((w, i) => (
              <div key={i} className="skel" style={{ width: i === 0 ? 38 : undefined, flex: i > 0 ? 1 : undefined, height: 300, borderRadius: 8 }} />
            ))}
          </div>
        ) : hetData && (
          <div style={{ position: 'relative', zIndex: 10, maxWidth: 600, margin: '0 auto 40px', padding: '0 16px', overflowX: 'auto' }}>
            <div style={{ display: 'grid', gridTemplateColumns: `38px repeat(5,minmax(72px,1fr))`, minWidth: 430 }}>
              {/* Headers */}
              <div style={{ borderBottom: '1px solid rgba(255,255,255,.07)' }} />
              {[1,2,3,4,5].map(n => (
                <div key={n} style={{ padding: '6px 3px 8px', textAlign: 'center', fontSize: 10, fontWeight: 600, letterSpacing: '.05em', textTransform: 'uppercase', color: n === mai ? '#f0c76b' : 'rgba(255,255,255,.3)', borderBottom: '1px solid rgba(255,255,255,.07)' }}>
                  {NAP[n]}{n === mai && <span className="pulse" style={{ display: 'inline-block', width: 4, height: 4, borderRadius: '50%', background: '#c8972a', marginLeft: 2, verticalAlign: 'middle' }} />}
                </div>
              ))}
              {/* Time col */}
              <div style={{ position: 'relative', borderRight: '1px solid rgba(255,255,255,.07)', height: H }}>
                {Array.from({ length: Math.floor((END - START) / 30) + 1 }, (_, i) => START + i * 30).map(m => (
                  <span key={m} style={{ position: 'absolute', right: 3, top: topPx(m), fontSize: 9, color: 'rgba(255,255,255,.22)', transform: 'translateY(-50%)', whiteSpace: 'nowrap', fontFamily: "'DM Mono',monospace" }}>
                    {Math.floor(m/60).toString().padStart(2,'0')}:{(m%60).toString().padStart(2,'0')}
                  </span>
                ))}
              </div>
              {/* Day cols */}
              {[1,2,3,4,5].map(n => {
                const isMai = n === mai
                const dayOrak = hetData[n] || []
                return (
                  <div key={n} style={{ position: 'relative', borderRight: '1px solid rgba(255,255,255,.04)', overflow: 'hidden', height: H, background: isMai ? 'rgba(200,151,42,.025)' : 'transparent' }}>
                    {Array.from({ length: Math.floor((END - START) / 30) + 1 }, (_, i) => START + i * 30).map(m => (
                      <div key={m} style={{ position: 'absolute', left: 0, right: 0, height: 1, top: topPx(m), background: m % 60 === 0 ? 'rgba(255,255,255,.08)' : 'rgba(255,255,255,.04)' }} />
                    ))}
                    {isMai && nowMin() >= START && nowMin() <= END && (
                      <div style={{ position: 'absolute', left: 0, right: 0, height: 2, top: topPx(nowMin()), zIndex: 15, background: 'linear-gradient(90deg,transparent,#ff6b82 20%,#ff6b82 80%,transparent)' }}>
                        <div style={{ position: 'absolute', left: 0, top: -4, width: 8, height: 8, borderRadius: '50%', background: '#ff6b82', boxShadow: '0 0 6px #ff6b82' }} />
                      </div>
                    )}
                    {dayOrak.map((o, oi) => {
                      const top = topPx(toMin(o.kezdes))
                      const h = Math.max(18, (toMin(o.vegzes) - toMin(o.kezdes)) * PPM)
                      const ak = isMai && isAktiv(o.kezdes, o.vegzes)
                      const mu = isMai && isMult(o.vegzes)
                      return (
                        <div key={oi} style={{ position: 'absolute', left: 2, right: 2, top, height: h, borderRadius: 6, padding: '3px 5px', overflow: 'hidden', border: '1px solid rgba(255,255,255,.07)', background: ak ? 'linear-gradient(160deg,rgba(200,151,42,.35),rgba(180,100,20,.3))' : 'linear-gradient(160deg,rgba(26,74,138,.8),rgba(11,46,89,.85))', borderColor: ak ? 'rgba(200,151,42,.55)' : undefined, opacity: mu ? .3 : 1 }}>
                          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 10, fontWeight: 700, color: ak ? '#f0c76b' : 'white', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', lineHeight: 1.2 }}>{o.tanar_nev || o.tanar}</div>
                          {h > 28 && <div style={{ fontSize: 8, color: 'rgba(255,255,255,.4)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', marginTop: 1 }}>{o.osztaly} · {o.tantargy}</div>}
                        </div>
                      )
                    })}
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </Layout>
    </div>
  )
}
