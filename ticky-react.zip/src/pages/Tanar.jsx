import { useState, useEffect, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Layout } from '../components/Layout'

function toMin(t) { const [h, m] = t.split(':').map(Number); return h * 60 + m }
function isAktiv(k, v) { const c = new Date().getHours() * 60 + new Date().getMinutes(); return c >= toMin(k) && c <= toMin(v) }
function isMult(v) { return new Date().getHours() * 60 + new Date().getMinutes() > toMin(v) }
function calcPct(k, v) { const c = new Date().getHours() * 60 + new Date().getMinutes(); return Math.min(100, Math.max(0, Math.round(((c - toMin(k)) / (toMin(v) - toMin(k))) * 100))) }

export default function Tanar() {
  const { kod } = useParams()
  const navigate = useNavigate()
  const [tanarok, setTanarok] = useState([])
  const [curKod, setCurKod] = useState(kod?.toUpperCase() || '')
  const [orak, setOrak] = useState(null)
  const [tanarNev, setTanarNev] = useState(null)
  const [szunet, setSzunet] = useState(null)
  const [uzenet, setUzenet] = useState(null)
  const [loading, setLoading] = useState(false)
  const [ido, setIdo] = useState(new Date().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' }))

  useEffect(() => {
    fetch('/api/tanarok').then(r => r.json()).then(d => setTanarok(d.tanarok || [])).catch(() => {})
  }, [])

  useEffect(() => {
    const t = setInterval(() => setIdo(new Date().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' })), 60000)
    return () => clearInterval(t)
  }, [])

  const loadData = useCallback(async (k) => {
    if (!k) return
    setLoading(true); setSzunet(null); setUzenet(null)
    try {
      const d = await fetch(`/api/tanar/${encodeURIComponent(k)}/orarend`).then(r => r.json())
      if (d.szunet) { setSzunet(d.szunet); setOrak([]); setLoading(false); return }
      if (d.uzenet && !d.orak?.length) { setUzenet(d.uzenet); setOrak([]); setLoading(false); return }
      if (d.error) { setUzenet(d.error); setOrak([]); setLoading(false); return }
      setOrak(d.orak || [])
      setTanarNev(d.tanar_nev || null)
    } catch(e) { setUzenet('Betöltési hiba') }
    setLoading(false)
  }, [])

  useEffect(() => { if (curKod) loadData(curKod) }, [curKod, loadData])

  const onSelect = (e) => {
    const v = e.target.value
    setCurKod(v)
    if (v) navigate(`/tanar/${encodeURIComponent(v)}`, { replace: true })
    else navigate('/tanar', { replace: true })
  }

  const akt = orak?.find(o => isAktiv(o.kezdes, o.vegzes))
  const kov = orak?.find(o => !isMult(o.vegzes) && !isAktiv(o.kezdes, o.vegzes))

  let bgClass = ''
  if (szunet || uzenet) bgClass = ''
  else if (akt) bgClass = 'tant'
  else if (orak?.length) bgClass = 'szabad'

  const allapotPill = () => {
    if (szunet) return { bg: 'rgba(200,151,42,.2)', border: 'rgba(200,151,42,.4)', color: '#f0c76b', dot: '#f0c76b', text: szunet }
    if (akt) return { bg: 'rgba(200,16,46,.25)', border: 'rgba(200,16,46,.4)', color: '#ff6b82', dot: '#ff6b82', text: 'TANÍT' }
    if (orak?.length) return { bg: 'rgba(26,138,74,.25)', border: 'rgba(26,138,74,.4)', color: '#4ade80', dot: '#4ade80', text: 'SZABAD' }
    return { bg: 'rgba(255,255,255,.08)', border: 'transparent', color: 'rgba(255,255,255,.4)', dot: 'rgba(255,255,255,.3)', text: '–' }
  }
  const pill = allapotPill()

  return (
    <Layout title="Tanár kereső">
      <div style={{
        position: 'relative', zIndex: 10, display: 'flex', justifyContent: 'center', padding: '24px 16px 60px',
        background: bgClass === 'tant'
          ? 'radial-gradient(ellipse 70% 55% at 15% 10%,rgba(200,16,46,.35) 0%,transparent 60%),radial-gradient(ellipse 50% 45% at 85% 85%,rgba(200,151,42,.15) 0%,transparent 55%)'
          : bgClass === 'szabad'
          ? 'radial-gradient(ellipse 70% 55% at 15% 10%,rgba(26,138,74,.35) 0%,transparent 60%),radial-gradient(ellipse 50% 45% at 85% 85%,rgba(26,74,138,.2) 0%,transparent 55%)'
          : undefined,
        transition: 'background .5s'
      }}>
        <div style={{ width: '100%', maxWidth: 440 }}>
          <div className="glass" style={{ borderRadius: 18, overflow: 'hidden' }}>
            {/* Header */}
            <div style={{ padding: '14px 20px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <a href="/" style={{ fontFamily: "'Playfair Display',serif", color: 'rgba(255,255,255,.35)', fontSize: 14, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}>
                <span className="pulse" style={{ width: 6, height: 6, borderRadius: '50%', background: '#c8972a', boxShadow: '0 0 6px #c8972a', display: 'inline-block' }} />Ticky
              </a>
              <span style={{ fontSize: 11, color: 'rgba(255,255,255,.28)' }}>Tanár kereső</span>
            </div>

            {/* Select */}
            <div style={{ padding: '14px 20px 18px', borderBottom: '1px solid rgba(255,255,255,.08)' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, marginBottom: 12 }}>
                <p style={{ fontSize: 10, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)' }}>Válassz tanárt</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 11px', borderRadius: 99, fontSize: 10, fontWeight: 600, background: pill.bg, border: `1px solid ${pill.border}`, color: pill.color, flexShrink: 0 }}>
                  <span className="pulse" style={{ width: 5, height: 5, borderRadius: '50%', background: pill.dot, display: 'inline-block' }} />
                  {pill.text}
                </div>
              </div>
              <select value={curKod} onChange={onSelect} style={{ width: '100%', padding: '12px 40px 12px 14px', borderRadius: 10, border: '1.5px solid rgba(255,255,255,.12)', background: 'rgba(255,255,255,.06)', color: 'white', fontSize: 15, appearance: 'none', cursor: 'pointer', backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='rgba(255,255,255,.4)' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 14px center', outline: 'none' }}>
                <option value="">— Válassz tanárt —</option>
                {tanarok.map(t => <option key={t.rovid_nev} value={t.rovid_nev} style={{ background: '#0b2e59' }}>{t.nev ? `${t.rovid_nev} – ${t.nev}` : t.rovid_nev}</option>)}
              </select>
            </div>

            {/* Aktív blokk */}
            <div style={{ padding: '18px 20px', borderBottom: '1px solid rgba(255,255,255,.08)', minHeight: 100 }}>
              {!curKod ? (
                <div style={{ textAlign: 'center', padding: '12px 0' }}>
                  <span style={{ fontSize: 32, display: 'block', marginBottom: 8 }}>👆</span>
                  <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)' }}>Válassz tanárt a legördülő menüből</p>
                </div>
              ) : loading ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div className="skel" style={{ height: 12, width: '40%' }} />
                  <div className="skel" style={{ height: 22, width: '60%' }} />
                  <div className="skel" style={{ height: 12 }} />
                </div>
              ) : szunet ? (
                <div style={{ textAlign: 'center', padding: '16px 0' }}>
                  <div style={{ fontSize: 36, marginBottom: 8 }}>🌙</div>
                  <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, color: '#f0c76b', marginBottom: 4 }}>{szunet}</p>
                  <p style={{ fontSize: 13, color: 'rgba(255,255,255,.45)' }}>Szünet idején nincs tanítás</p>
                </div>
              ) : uzenet ? (
                <div style={{ textAlign: 'center', padding: '12px 0' }}>
                  <span style={{ fontSize: 28, display: 'block', marginBottom: 8 }}>🌙</span>
                  <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)' }}>{uzenet}</p>
                </div>
              ) : akt ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <div>
                    <p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', marginBottom: 2 }}>Most itt van</p>
                    <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, fontWeight: 700, color: 'white', lineHeight: 1.1 }}>{akt.terem}. terem</p>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                    {[['Osztály', akt.osztaly], ['Tantárgy', akt.tantargy]].map(([l, v]) => (
                      <div key={l}><p style={{ fontSize: 9, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.3)', marginBottom: 2 }}>{l}</p><p style={{ fontFamily: "'Playfair Display',serif", fontSize: 16, fontWeight: 700, color: 'white' }}>{v}</p></div>
                    ))}
                  </div>
                  <div>
                    <div style={{ height: 5, borderRadius: 3, overflow: 'hidden', background: 'rgba(255,255,255,.08)' }}>
                      <div style={{ height: '100%', width: `${calcPct(akt.kezdes, akt.vegzes)}%`, background: 'linear-gradient(90deg,#e8334a,#ff6b82)', transition: 'width .6s' }} />
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4, fontSize: 11, color: 'rgba(255,255,255,.35)' }}>
                      <span>{akt.kezdes}</span><span style={{ color: '#ff6b82', fontWeight: 600 }}>{akt.vegzes}-ig</span><span>{akt.vegzes}</span>
                    </div>
                  </div>
                </div>
              ) : kov ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '4px 0' }}>
                  <span style={{ fontSize: 26 }}>☕</span>
                  <div>
                    <p style={{ fontWeight: 600, color: 'rgba(255,255,255,.8)' }}>Jelenleg szabad</p>
                    <p style={{ fontSize: 12, marginTop: 2, color: 'rgba(255,255,255,.4)' }}>Következő: <strong style={{ color: 'rgba(255,255,255,.7)' }}>{kov.terem}. terem</strong> · {kov.kezdes}–{kov.vegzes}</p>
                  </div>
                </div>
              ) : orak?.length === 0 ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '4px 0' }}>
                  <span style={{ fontSize: 26 }}>✅</span>
                  <div><p style={{ fontWeight: 600, color: '#4ade80' }}>Szabad</p><p style={{ fontSize: 12, marginTop: 2, color: 'rgba(255,255,255,.4)' }}>Ma már nincs több óra</p></div>
                </div>
              ) : null}
            </div>

            {/* Napirend lista */}
            <div style={{ padding: '16px 20px' }}>
              <p style={{ fontSize: 10, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.28)', marginBottom: 12 }}>Mai napirend</p>
              {!curKod || loading || szunet ? (
                <p style={{ fontSize: 13, color: 'rgba(255,255,255,.3)' }}>{!curKod ? 'Nincs kiválasztva tanár' : loading ? '…' : '–'}</p>
              ) : !orak?.length ? (
                <p style={{ fontSize: 13, color: 'rgba(255,255,255,.35)' }}>Nincs mai óra</p>
              ) : orak.map((o, i) => {
                const ak = isAktiv(o.kezdes, o.vegzes), mu = isMult(o.vegzes)
                return (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 10px', margin: '0 -4px', borderRadius: 10, background: ak ? 'rgba(200,16,46,.12)' : 'transparent', borderLeft: ak ? '3px solid #e8334a' : undefined, opacity: mu ? .38 : 1 }}>
                    <span style={{ fontFamily: "'Playfair Display',serif", fontWeight: 700, fontSize: 16, color: mu ? 'rgba(255,255,255,.2)' : 'rgba(255,255,255,.85)', width: 20, textAlign: 'right', flexShrink: 0 }}>{o.ora_sorszam || i + 1}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, flexWrap: 'wrap' }}>
                        <span style={{ fontSize: 13, fontWeight: 500, color: mu ? 'rgba(255,255,255,.3)' : 'rgba(255,255,255,.8)' }}>{o.terem}. terem</span>
                        <span style={{ fontSize: 11, color: 'rgba(255,255,255,.35)' }}>{o.osztaly} · {o.tantargy}</span>
                      </div>
                      <p style={{ fontSize: 11, color: 'rgba(255,255,255,.28)' }}>{o.kezdes} – {o.vegzes}</p>
                    </div>
                    {ak && <span className="pulse" style={{ width: 7, height: 7, borderRadius: '50%', background: '#ff6b82', display: 'inline-block', flexShrink: 0 }} />}
                  </div>
                )
              })}
            </div>

            {/* Footer */}
            <div style={{ padding: '12px 20px', borderTop: '1px solid rgba(255,255,255,.08)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 12, color: 'rgba(255,255,255,.35)' }}>{ido}</span>
              <button onClick={() => loadData(curKod)} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', borderRadius: 8, fontSize: 12, color: 'rgba(255,255,255,.4)', border: '1px solid rgba(255,255,255,.10)', background: 'transparent', cursor: 'pointer' }}>
                🔄 Frissít
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  )
}
