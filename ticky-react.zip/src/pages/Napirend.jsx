import { useState, useEffect, useCallback } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Layout } from '../components/Layout'

function toMin(t) { const [h, m] = t.split(':').map(Number); return h * 60 + m }
function nowMin() { const n = new Date(); return n.getHours() * 60 + n.getMinutes() }
function isAktiv(k, v) { const c = nowMin(); return c >= toMin(k) && c <= toMin(v) }
function isMult(v) { return nowMin() > toMin(v) }
function calcPct(k, v) { return Math.min(100, Math.max(0, Math.round(((nowMin() - toMin(k)) / (toMin(v) - toMin(k))) * 100))) }

const NAP = {1:'Hétfő',2:'Kedd',3:'Szerda',4:'Csütörtök',5:'Péntek'}
const NAP_SHORT = {1:'H',2:'K',3:'Sze',4:'Cs',5:'P'}
const START = 7*60+30, END = 14*60+30, PPM = 1.9
const H = (END - START) * PPM
function topPx(m) { return Math.max(0, (m - START) * PPM) }
function maiNap() { const d = new Date().getDay(); return d === 0 || d === 6 ? 1 : d }

export default function Napirend() {
  const { szam } = useParams()
  const terem = szam?.toUpperCase()
  const [hetData, setHetData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [szunet, setSzunet] = useState(null)
  const [curMob, setCurMob] = useState(maiNap())
  const [ido, setIdo] = useState(new Date().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' }))

  const loadData = useCallback(async () => {
    try {
      const d = await fetch(`/api/napirend/${encodeURIComponent(terem)}?nap=heten`).then(r => r.json())
      if (d.error) { setLoading(false); return }
      if (d.szunet) { setSzunet(d.szunet); setLoading(false); return }
      const het = {}
      ;(d.het || []).forEach(nd => { het[nd.nap] = nd.orak || [] })
      setHetData(het); setLoading(false)
    } catch(e) { setLoading(false) }
    setIdo(new Date().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' }))
  }, [terem])

  useEffect(() => { loadData(); const t = setInterval(loadData, 5 * 60000); return () => clearInterval(t) }, [loadData])

  const mai = maiNap()
  const ticks = Array.from({ length: Math.floor((END - START) / 30) + 1 }, (_, i) => START + i * 30)

  const summary = () => {
    const orak = hetData?.[mai] || []
    if (!orak.length) return <span>📭 Ma nincs óra</span>
    const akt = orak.find(o => isAktiv(o.kezdes, o.vegzes))
    const kov = orak.find(o => !isMult(o.vegzes) && !isAktiv(o.kezdes, o.vegzes))
    return <>
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 11px', borderRadius: 8, fontSize: 11, background: 'rgba(255,255,255,.05)', border: '1px solid rgba(255,255,255,.08)', color: 'rgba(255,255,255,.55)' }}>📚 {orak.length} óra ma</span>
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 11px', borderRadius: 8, fontSize: 11, background: 'rgba(255,255,255,.05)', border: '1px solid rgba(255,255,255,.08)', color: 'rgba(255,255,255,.55)' }}>🕐 {orak[0].kezdes}–{orak[orak.length - 1].vegzes}</span>
      {akt && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 11px', borderRadius: 8, fontSize: 11, background: 'rgba(200,151,42,.12)', border: '1px solid rgba(200,151,42,.25)', color: '#f0c76b' }}>⚡ {100 - calcPct(akt.kezdes, akt.vegzes)}% van hátra</span>}
    </>
  }

  return (
    <Layout title="">
      <div style={{ position: 'relative', zIndex: 10, maxWidth: 1200, margin: '0 auto', padding: '16px 16px 0' }}>
        <div style={{ marginBottom: 6 }}>
          <a href="/" style={{ fontFamily: "'Playfair Display',serif", color: 'rgba(255,255,255,.3)', fontSize: 12, fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 5 }}>
            <span className="pulse" style={{ width: 5, height: 5, borderRadius: '50%', background: '#c8972a', display: 'inline-block' }} />Ticky
          </a>
        </div>
        <p style={{ fontSize: 10, fontWeight: 600, letterSpacing: '.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,.28)', marginBottom: 3 }}>Terem · Heti napirend</p>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap', paddingBottom: 8 }}>
          <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(36px,10vw,52px)', fontWeight: 700, color: 'white', lineHeight: 1, letterSpacing: -1 }}>{terem}</h1>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', paddingBottom: 4 }}>
            {loading ? <div className="skel" style={{ width: 100, height: 26, borderRadius: 8 }} /> : summary()}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 8 }}>
          <span style={{ fontSize: 12, color: 'rgba(255,255,255,.3)' }}>{ido}</span>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <Link to={`/terem/${terem}`} style={{ fontSize: 12, padding: '6px 12px', borderRadius: 8, color: 'rgba(255,255,255,.5)', border: '1px solid rgba(255,255,255,.1)', background: 'rgba(255,255,255,.04)' }}>← Vissza</Link>
            <button onClick={loadData} style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '6px 10px', borderRadius: 8, fontSize: 12, color: 'rgba(255,255,255,.4)', border: '1px solid rgba(255,255,255,.10)', background: 'transparent', cursor: 'pointer' }}>🔄</button>
          </div>
        </div>
      </div>

      {szunet ? (
        <div style={{ textAlign: 'center', padding: '80px 20px', position: 'relative', zIndex: 10 }}>
          <div style={{ fontSize: 56, marginBottom: 16 }}>🌙</div>
          <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, fontWeight: 700, color: '#f0c76b', marginBottom: 8 }}>{szunet}</p>
          <p style={{ color: 'rgba(255,255,255,.4)' }}>Szünet idején nincs tanítás</p>
        </div>
      ) : loading ? (
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 16px', display: 'flex', gap: 5 }}>
          {[38, 1, 1, 1, 1, 1].map((w, i) => <div key={i} className="skel" style={{ width: i === 0 ? 38 : undefined, flex: i > 0 ? 1 : undefined, height: 500, borderRadius: 8 }} />)}
        </div>
      ) : hetData && (
        <>
          {/* Desktop grid */}
          <div style={{ position: 'relative', zIndex: 10, maxWidth: 1200, margin: '16px auto 0', padding: '0 16px', overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
            <div style={{ display: 'grid', gridTemplateColumns: `42px repeat(5,minmax(100px,1fr))`, minWidth: 560 }}>
              <div style={{ borderBottom: '1px solid rgba(255,255,255,.08)' }} />
              {[1,2,3,4,5].map(n => (
                <div key={n} style={{ padding: '7px 5px 9px', textAlign: 'center', fontSize: 10, fontWeight: 600, letterSpacing: '.05em', textTransform: 'uppercase', color: n === mai ? '#f0c76b' : 'rgba(255,255,255,.35)', borderBottom: '1px solid rgba(255,255,255,.08)' }}>
                  {NAP[n]}{n === mai && <span className="pulse" style={{ display: 'inline-block', width: 4, height: 4, borderRadius: '50%', background: '#c8972a', marginLeft: 3, verticalAlign: 'middle' }} />}
                </div>
              ))}
              <div style={{ position: 'relative', borderRight: '1px solid rgba(255,255,255,.08)', height: H }}>
                {ticks.map(m => (
                  <span key={m} style={{ position: 'absolute', right: 4, top: topPx(m), fontSize: 9, color: 'rgba(255,255,255,.25)', transform: 'translateY(-50%)', whiteSpace: 'nowrap', fontFamily: "'DM Mono',monospace" }}>
                    {Math.floor(m/60).toString().padStart(2,'0')}:{(m%60).toString().padStart(2,'0')}
                  </span>
                ))}
              </div>
              {[1,2,3,4,5].map(n => {
                const isMai = n === mai
                const dayOrak = hetData[n] || []
                return (
                  <div key={n} style={{ position: 'relative', borderRight: '1px solid rgba(255,255,255,.04)', overflow: 'hidden', height: H, background: isMai ? 'rgba(200,151,42,.02)' : 'transparent' }}>
                    {ticks.map(m => <div key={m} style={{ position: 'absolute', left: 0, right: 0, height: 1, top: topPx(m), background: m % 60 === 0 ? 'rgba(255,255,255,.09)' : 'rgba(255,255,255,.05)' }} />)}
                    {isMai && nowMin() >= START && nowMin() <= END && (
                      <div style={{ position: 'absolute', left: 0, right: 0, height: 2, top: topPx(nowMin()), zIndex: 15, background: 'linear-gradient(90deg,transparent,#ff6b82 20%,#ff6b82 80%,transparent)' }}>
                        <div style={{ position: 'absolute', left: 0, top: -4, width: 9, height: 9, borderRadius: '50%', background: '#ff6b82', boxShadow: '0 0 8px #ff6b82' }} />
                      </div>
                    )}
                    {dayOrak.map((o, oi) => {
                      const top = topPx(toMin(o.kezdes))
                      const h = Math.max(22, (toMin(o.vegzes) - toMin(o.kezdes)) * PPM)
                      const ak = isMai && isAktiv(o.kezdes, o.vegzes)
                      const mu = isMai && isMult(o.vegzes)
                      const p = ak ? calcPct(o.kezdes, o.vegzes) : 0
                      return (
                        <div key={oi} title={`${o.tanar_nev || o.tanar} · ${o.osztaly} · ${o.tantargy}`} style={{ position: 'absolute', left: 2, right: 2, top, height: h, borderRadius: 7, padding: '4px 6px', overflow: 'hidden', border: `1px solid ${ak ? 'rgba(200,151,42,.55)' : 'rgba(255,255,255,.08)'}`, background: ak ? 'linear-gradient(160deg,rgba(200,151,42,.35),rgba(180,100,20,.3))' : 'linear-gradient(160deg,rgba(26,74,138,.85),rgba(11,46,89,.9))', opacity: mu ? .32 : 1 }}>
                          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 11, fontWeight: 700, color: ak ? '#f0c76b' : 'white', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', lineHeight: 1.2 }}>{o.tanar_nev || o.tanar}</div>
                          {h > 34 && <div style={{ fontSize: 9, color: 'rgba(255,255,255,.45)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', marginTop: 1 }}>{o.osztaly} · {o.tantargy}</div>}
                          {ak && <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 3, background: 'rgba(255,255,255,.06)', borderRadius: '0 0 7px 7px', overflow: 'hidden' }}><div style={{ height: '100%', width: `${p}%`, background: 'linear-gradient(90deg,#c8972a,#f0c76b)' }} /></div>}
                        </div>
                      )
                    })}
                  </div>
                )
              })}
            </div>
          </div>

          {/* Mobile tabs */}
          <div style={{ marginTop: 16 }}>
            <div style={{ display: 'flex', gap: 4, overflowX: 'auto', padding: '0 16px 12px', scrollbarWidth: 'none' }}>
              {[1,2,3,4,5].map(n => (
                <button key={n} onClick={() => setCurMob(n)} style={{ padding: '7px 12px', borderRadius: 8, fontSize: 12, fontWeight: 500, background: curMob === n ? 'rgba(200,151,42,.15)' : 'transparent', border: curMob === n ? '1px solid rgba(200,151,42,.4)' : '1px solid transparent', color: curMob === n ? '#f0c76b' : n === mai ? 'rgba(255,255,255,.7)' : 'rgba(255,255,255,.4)', cursor: 'pointer', whiteSpace: 'nowrap' }}>
                  {NAP[n]}{n === mai ? ' · Ma' : ''}
                </button>
              ))}
            </div>
            <div style={{ padding: '0 16px 40px', maxWidth: 480, margin: '0 auto' }}>
              {(hetData[curMob] || []).length === 0 ? (
                <div style={{ textAlign: 'center', padding: '32px 0' }}>📭<p style={{ color: 'rgba(255,255,255,.5)', marginTop: 10 }}>Nincs óra ezen a napon</p></div>
              ) : (hetData[curMob] || []).map((o, i) => {
                const isMai = curMob === mai
                const ak = isMai && isAktiv(o.kezdes, o.vegzes)
                const mu = isMai && isMult(o.vegzes)
                const p = ak ? calcPct(o.kezdes, o.vegzes) : 0
                const prev = hetData[curMob][i - 1]
                const szunetPerc = prev ? toMin(o.kezdes) - toMin(prev.vegzes) : 0
                return (
                  <div key={i}>
                    {szunetPerc > 0 && <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '2px 10px 7px', color: 'rgba(255,255,255,.18)', fontSize: 10 }}><div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,.05)' }} /><span>{szunetPerc} perc szünet</span><div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,.05)' }} /></div>}
                    <div style={{ display: 'flex', alignItems: 'stretch', borderRadius: 12, overflow: 'hidden', border: ak ? '1px solid rgba(200,151,42,.5)' : '1px solid rgba(255,255,255,.07)', marginBottom: 7, background: ak ? 'rgba(200,151,42,.06)' : 'transparent', opacity: mu ? .38 : 1 }}>
                      <div style={{ fontFamily: "'Playfair Display',serif", fontWeight: 700, fontSize: 17, color: ak ? '#f0c76b' : 'rgba(255,255,255,.2)', width: 38, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: ak ? 'rgba(200,151,42,.08)' : 'rgba(255,255,255,.03)', borderRight: `1px solid ${ak ? 'rgba(200,151,42,.2)' : 'rgba(255,255,255,.06)'}` }}>{o.ora_sorszam || i + 1}</div>
                      <div style={{ flex: 1, padding: '9px 12px', minWidth: 0 }}>
                        <div style={{ fontSize: 10, color: 'rgba(255,255,255,.28)', fontWeight: 500, marginBottom: 2 }}>{o.kezdes} – {o.vegzes}</div>
                        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 14, fontWeight: 700, color: 'white', lineHeight: 1.2 }}>{o.tanar_nev || o.tanar}</div>
                        <div style={{ fontSize: 11, color: 'rgba(255,255,255,.38)', marginTop: 2 }}>{o.osztaly} · {o.tantargy}</div>
                      </div>
                      {ak && <div style={{ width: 4, flexShrink: 0, background: 'rgba(255,255,255,.05)', position: 'relative', overflow: 'hidden' }}><div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'linear-gradient(to top,#c8972a,#f0c76b)', height: `${p}%` }} /></div>}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </>
      )}
    </Layout>
  )
}
