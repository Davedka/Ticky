import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Link } from 'react-router-dom'

export default function Login() {
  const [fnev, setFnev] = useState('')
  const [pw, setPw] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const redirect = params.get('redirect') || '/'

  const doLogin = async () => {
    if (!fnev || !pw) { setError('Töltsd ki mindkét mezőt!'); return }
    setLoading(true); setError('')
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ felhasznalonev: fnev, jelszo: pw })
      })
      const d = await res.json()
      if (d.ok) { const dest = decodeURIComponent(redirect); navigate(dest.startsWith('/') ? dest : '/') }
      else setError(d.error || 'Hibás felhasználónév vagy jelszó')
    } catch(e) { setError('Nem sikerült csatlakozni a szerverhez') }
    setLoading(false)
  }

  const onKey = (e) => { if (e.key === 'Enter') doLogin() }

  return (
    <div style={{ background: '#04090f', minHeight: '100vh', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundImage: 'radial-gradient(ellipse 70% 50% at 10% 0%,rgba(26,74,138,.4) 0%,transparent 55%),radial-gradient(ellipse 50% 40% at 90% 100%,rgba(200,151,42,.10) 0%,transparent 50%)' }}>
      <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0, backgroundImage: 'linear-gradient(rgba(255,255,255,.015) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.015) 1px,transparent 1px)', backgroundSize: '44px 44px' }} />
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: 2, zIndex: 200, background: 'linear-gradient(90deg,transparent,#c8972a 30%,#f0c76b 50%,#c8972a 70%,transparent)' }} />

      <div style={{ position: 'relative', zIndex: 10, width: '100%', maxWidth: 360, padding: '0 16px', animation: 'fu .5s cubic-bezier(.22,1,.36,1) both' }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <Link to="/" style={{ fontFamily: "'Playfair Display',serif", fontSize: 32, fontWeight: 700, color: 'white', display: 'inline-flex', alignItems: 'center', gap: 10 }}>
            <span className="pulse" style={{ width: 10, height: 10, borderRadius: '50%', background: '#c8972a', boxShadow: '0 0 10px #c8972a', display: 'inline-block' }} />
            Ticky
          </Link>
          <p style={{ fontSize: 13, color: 'rgba(255,255,255,.4)', marginTop: 8 }}>Bejelentkezés</p>
        </div>

        <div className="glass" style={{ borderRadius: 16, padding: 28 }}>
          {error && <div style={{ fontSize: 13, color: '#ff6b82', padding: '10px 14px', borderRadius: 8, background: 'rgba(232,51,74,.12)', border: '1px solid rgba(232,51,74,.3)', marginBottom: 16 }}>{error}</div>}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,.35)', letterSpacing: '.07em', textTransform: 'uppercase', display: 'block', marginBottom: 7 }}>Felhasználónév</label>
              <input type="text" className="inp" placeholder="felhasznalonev" autoComplete="username" autoFocus value={fnev} onChange={e => setFnev(e.target.value)} onKeyDown={onKey} />
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,.35)', letterSpacing: '.07em', textTransform: 'uppercase', display: 'block', marginBottom: 7 }}>Jelszó</label>
              <input type="password" className="inp" placeholder="••••••••" autoComplete="current-password" value={pw} onChange={e => setPw(e.target.value)} onKeyDown={onKey} />
            </div>
            <button className="btn btn-gold" style={{ width: '100%', justifyContent: 'center', padding: 13, fontSize: 14 }} onClick={doLogin} disabled={loading}>
              {loading ? '⟳ Bejelentkezés…' : 'Bejelentkezés'}
            </button>
          </div>
          <p style={{ textAlign: 'center', marginTop: 16, fontSize: 11, color: 'rgba(255,255,255,.2)' }}>Admin belépés: <Link to="/admin" style={{ color: 'rgba(255,255,255,.4)' }}>Admin panel</Link></p>
        </div>
        <p style={{ textAlign: 'center', marginTop: 14 }}><Link to="/" style={{ fontSize: 12, color: 'rgba(255,255,255,.3)' }}>← Vissza a főoldalra</Link></p>
      </div>
    </div>
  )
}
