import { useState, useEffect } from 'react'
import { NavLink, Link, useNavigate } from 'react-router-dom'

const NAV_LINKS = [
  { to: '/termek', label: 'Termek' },
  { to: '/tanar', label: 'Tanár' },
  { to: '/osztaly', label: 'Osztály' },
  { to: '/qr', label: 'QR' },
  { to: '/kijelzo', label: 'Kijelző' },
]

export function Layout({ children, title }) {
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const close = (e) => {
      if (!e.target.closest('#tn-mobile') && !e.target.closest('#tn-hamburger')) setMenuOpen(false)
    }
    document.addEventListener('click', close)
    return () => document.removeEventListener('click', close)
  }, [])

  return (
    <div style={{ background: '#060f1e', minHeight: '100vh', color: 'white' }}>
      <div className="top-line" />
      <div
        style={{
          position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0,
          backgroundImage: 'linear-gradient(rgba(255,255,255,.02) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.02) 1px,transparent 1px)',
          backgroundSize: '40px 40px'
        }}
      />

      {/* Sidebar */}
      <div className="ticky-sidebar">
        <a href="https://esemenynaptar.onrender.com/" target="_blank" rel="noopener" className="tsb-item" data-label="Eseménynaptár">📅</a>
        <div className="tsb-divider" />
        <Link to="/support" className="tsb-item" data-label="Support">✉️</Link>
        <a href="https://github.com/Davedka/Ticky/issues/new" target="_blank" rel="noopener" className="tsb-item" data-label="Bug report">🐛</a>
      </div>

      {/* Navbar */}
      <nav className="ticky-navbar">
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 0, overflow: 'hidden' }}>
          <Link to="/" className="tn-brand">
            <span className="pulse" style={{ width: 7, height: 7, borderRadius: '50%', background: '#c8972a', boxShadow: '0 0 8px #c8972a', display: 'inline-block', flexShrink: 0 }} />
            Ticky
          </Link>
          {title && <>
            <span style={{ color: 'rgba(255,255,255,.2)', margin: '0 2px' }}>·</span>
            <span style={{ fontSize: 14, color: 'rgba(255,255,255,.45)', fontWeight: 400, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 150 }}>{title}</span>
          </>}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div className="tn-links" style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            {NAV_LINKS.map(l => (
              <NavLink key={l.to} to={l.to} className={({ isActive }) => `tn-link${isActive ? ' active' : ''}`}>{l.label}</NavLink>
            ))}
            <NavLink to="/admin" className={({ isActive }) => `tn-link gold${isActive ? ' active' : ''}`}>⚙️ Admin</NavLink>
          </div>
          <div id="tn-hamburger" className="tn-hamburger" onClick={() => setMenuOpen(o => !o)}>
            <span /><span /><span />
          </div>
        </div>
      </nav>

      {/* Mobile menu */}
      <div id="tn-mobile" className={`tn-mobile${menuOpen ? ' open' : ''}`}>
        {NAV_LINKS.map(l => (
          <NavLink key={l.to} to={l.to} className={({ isActive }) => isActive ? 'active' : ''} onClick={() => setMenuOpen(false)}>{l.label}</NavLink>
        ))}
        <Link to="/support" onClick={() => setMenuOpen(false)}>✉️ Support</Link>
        <a href="https://github.com/Davedka/Ticky/issues/new" target="_blank" rel="noopener">🐛 Bug report</a>
        <NavLink to="/admin" className="mm-gold" onClick={() => setMenuOpen(false)}>⚙️ Admin</NavLink>
      </div>

      <div style={{ position: 'relative', zIndex: 10 }}>
        {children}
      </div>
    </div>
  )
}

export function Toast({ message, type = 'ok', onClose }) {
  useEffect(() => {
    const t = setTimeout(onClose, 3000)
    return () => clearTimeout(t)
  }, [onClose])
  return <div className={`toast ${type}`}>{message}</div>
}

export function useToast() {
  const [toasts, setToasts] = useState([])
  const add = (msg, type = 'ok') => setToasts(t => [...t, { id: Date.now(), msg, type }])
  const remove = (id) => setToasts(t => t.filter(x => x.id !== id))
  const ToastContainer = () => toasts.map(t => <Toast key={t.id} message={t.msg} type={t.type} onClose={() => remove(t.id)} />)
  return { toast: add, ToastContainer }
}

export function Skeleton({ style }) {
  return <div className="skel" style={style} />
}

export function SzunetBanner({ szunet }) {
  if (!szunet) return null
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 16px', borderRadius: 12, background: 'rgba(200,151,42,.12)', border: '1px solid rgba(200,151,42,.3)', color: '#f0c76b', fontSize: 13, fontWeight: 600, marginBottom: 16 }}>
      <span>🌙</span><span>{szunet} – szünet idején nincs tanítás</span>
    </div>
  )
}
